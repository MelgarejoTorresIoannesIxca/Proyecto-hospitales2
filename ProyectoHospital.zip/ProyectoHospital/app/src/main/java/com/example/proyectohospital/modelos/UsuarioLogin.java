package com.example.proyectohospital.modelos;

public class UsuarioLogin {
    public int exito;                    // 0 = error, 1 = éxito
    public String mensaje;
    public int idUsuarios;
    public String nombre;
    public String apellidoP;
    public String apellidoM;
    public String correoElectronico;
    public int TipoUsuario;              // 1 = Paciente, 2 = Doctor

    public UsuarioLogin() {
    }

    public UsuarioLogin(int exito, String mensaje) {
        this.exito = exito;
        this.mensaje = mensaje;
    }

    public UsuarioLogin(int exito, String mensaje, int idUsuarios, String nombre,
                        String apellidoP, String apellidoM, String correoElectronico, int TipoUsuario) {
        this.exito = exito;
        this.mensaje = mensaje;
        this.idUsuarios = idUsuarios;
        this.nombre = nombre;
        this.apellidoP = apellidoP;
        this.apellidoM = apellidoM;
        this.correoElectronico = correoElectronico;
        this.TipoUsuario = TipoUsuario;
    }

    // Getters y Setters
    public int getExito() {
        return exito;
    }

    public void setExito(int exito) {
        this.exito = exito;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public int getIdUsuarios() {
        return idUsuarios;
    }

    public void setIdUsuarios(int idUsuarios) {
        this.idUsuarios = idUsuarios;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoP() {
        return apellidoP;
    }

    public void setApellidoP(String apellidoP) {
        this.apellidoP = apellidoP;
    }

    public String getApellidoM() {
        return apellidoM;
    }

    public void setApellidoM(String apellidoM) {
        this.apellidoM = apellidoM;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public int getTipoUsuario() {
        return TipoUsuario;
    }

    public void setTipoUsuario(int tipoUsuario) {
        this.TipoUsuario = tipoUsuario;
    }
}
