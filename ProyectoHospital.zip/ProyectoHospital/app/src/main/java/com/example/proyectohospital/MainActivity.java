package com.example.proyectohospital;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyectohospital.InicioSesion.InicioSesion;
import com.example.proyectohospital.InicioSesion.Registrarse;
import com.example.proyectohospital.InicioSesion.UsuarioIniciado;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private static final String PREF_NAME = "SesionUsuario";
    private static final String KEY_TOKEN = "token";

    // Launcher para solicitar permisos de notificaciones
    private ActivityResultLauncher<String> requestPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inicializar el launcher de permisos ANTES de verificar sesión
        inicializarLauncherPermisos();

        // Revisamos sesión
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        String tokenGuardado = sharedPreferences.getString(KEY_TOKEN, null);

        if (tokenGuardado != null) {
            // Si ya hay token → solicitar permisos y luego ir a UsuarioIniciado
            Log.d(TAG, "Sesión encontrada, verificando permisos...");
            solicitarPermisosNotificaciones();

            Intent intent = new Intent(this, UsuarioIniciado.class);
            startActivity(intent);
            finish();
            return;
        }

        // Si no hay sesión → mostrar MainActivity normal
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button btnLogin = findViewById(R.id.btnMainLogin);
        Button btnRegistro = findViewById(R.id.btnMainRegistro);

        btnLogin.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, InicioSesion.class);
            startActivity(intent);
        });

        btnRegistro.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, Registrarse.class);
            startActivity(intent);
        });

        // Verificar estado de notificaciones al iniciar (solo log)
        verificarEstadoNotificaciones();
    }

    /**
     * Inicializa el launcher para solicitar permisos de notificaciones
     */
    private void inicializarLauncherPermisos() {
        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        Log.d(TAG, "✓ Permiso de notificaciones concedido");
                        Toast.makeText(this, "✓ Notificaciones habilitadas", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.w(TAG, "✗ Permiso de notificaciones denegado");
                        Toast.makeText(this, "⚠️ No recibirás recordatorios de medicamentos", Toast.LENGTH_SHORT).show();
                        // Mostrar diálogo para ir a configuración
                        mostrarDialogoConfiguracion();
                    }
                }
        );
    }

    /**
     * Solicita permisos de notificaciones (solo para Android 13+)
     */
    private void solicitarPermisosNotificaciones() {
        // Solo para Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {

                Log.d(TAG, "Solicitando permiso de notificaciones...");

                // Verificar si debemos mostrar una explicación
                if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                    // Mostrar diálogo explicativo
                    mostrarDialogoExplicativo();
                } else {
                    // Solicitar directamente
                    requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
                }
            } else {
                Log.d(TAG, "Permiso de notificaciones ya concedido");
            }
        } else {
            Log.d(TAG, "Android < 13, no se requiere solicitar permiso POST_NOTIFICATIONS");
        }
    }

    /**
     * Muestra un diálogo explicando por qué necesitamos el permiso
     */
    private void mostrarDialogoExplicativo() {
        new AlertDialog.Builder(this)
                .setTitle("🔔 Notificaciones de Medicamentos")
                .setMessage("Esta aplicación necesita enviar notificaciones para recordarte tomar tus medicamentos a tiempo.\n\n" +
                        "Sin este permiso, no recibirás recordatorios y podrías olvidar tus medicamentos.")
                .setPositiveButton("Permitir", (dialog, which) -> {
                    requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
                })
                .setNegativeButton("No, gracias", (dialog, which) -> {
                    Toast.makeText(this, "⚠️ No recibirás recordatorios", Toast.LENGTH_SHORT).show();
                })
                .setCancelable(false)
                .show();
    }

    /**
     * Muestra un diálogo para ir a la configuración de la app
     */
    private void mostrarDialogoConfiguracion() {
        new AlertDialog.Builder(this)
                .setTitle("⚙️ Permisos Requeridos")
                .setMessage("Para recibir recordatorios de medicamentos, necesitas habilitar las notificaciones manualmente.\n\n" +
                        "¿Deseas ir a la configuración de la app?")
                .setPositiveButton("Ir a Configuración", (dialog, which) -> {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", getPackageName(), null);
                    intent.setData(uri);
                    startActivity(intent);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    /**
     * Verifica si las notificaciones están habilitadas (solo para logs)
     */
    private void verificarEstadoNotificaciones() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            if (notificationManager != null) {
                boolean enabled = notificationManager.areNotificationsEnabled();
                Log.d(TAG, "Estado de notificaciones: " + (enabled ? "HABILITADAS ✓" : "DESHABILITADAS ✗"));

                if (!enabled) {
                    Log.w(TAG, "⚠️ Las notificaciones están deshabilitadas en el sistema");
                }
            }
        } else {
            Log.d(TAG, "Android < 8, no se puede verificar estado de notificaciones");
        }
    }

    /**
     * Método público para verificar si las notificaciones están habilitadas
     * (puede ser usado desde otras activities)
     */
    public static boolean notificacionesHabilitadas(Context context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager notificationManager =
                    (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            return notificationManager != null && notificationManager.areNotificationsEnabled();
        }
        return true; // En versiones antiguas asumimos que están habilitadas
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Verificar nuevamente cuando la actividad regresa al frente
        // (por ejemplo, después de cambiar permisos en configuración)
        verificarEstadoNotificaciones();
    }
}