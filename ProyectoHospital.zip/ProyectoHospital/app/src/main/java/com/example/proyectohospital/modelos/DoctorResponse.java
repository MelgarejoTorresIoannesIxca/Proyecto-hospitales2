package com.example.proyectohospital.modelos;

import java.util.List;

public class DoctorResponse {
    private List<Doctor> doctores;

    public List<Doctor> getDoctores() {
        return doctores;
    }

    public void setDoctores(List<Doctor> doctores) {
        this.doctores = doctores;
    }
}
