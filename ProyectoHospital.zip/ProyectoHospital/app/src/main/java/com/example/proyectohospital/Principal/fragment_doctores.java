package com.example.proyectohospital.Principal;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectohospital.R;
import com.example.proyectohospital.adaptadores.DoctorAdapter;
import com.example.proyectohospital.modelos.Doctor;
import com.example.proyectohospital.navegacion.ApiService;
import com.example.proyectohospital.navegacion.RetrofitClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class fragment_doctores extends Fragment {

    private RecyclerView recyclerDoctores;
    private DoctorAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_doctores, container, false);

        recyclerDoctores = view.findViewById(R.id.recyclerDoctores);
        recyclerDoctores.setLayoutManager(new LinearLayoutManager(getContext()));

        adapter = new DoctorAdapter(getContext());
        recyclerDoctores.setAdapter(adapter);

        cargarDoctores();

        return view;
    }

    private void cargarDoctores() {

        if (getContext() == null) return;

        ApiService api = RetrofitClient.getClient().create(ApiService.class);

        api.getTopDoctores().enqueue(new Callback<List<Doctor>>() {
            @Override
            public void onResponse(Call<List<Doctor>> call, Response<List<Doctor>> response) {

                if (!response.isSuccessful()) {
                    Toast.makeText(getContext(), "Error en la respuesta del servidor", Toast.LENGTH_SHORT).show();
                    Log.e("API", "Código HTTP: " + response.code());
                    return;
                }

                List<Doctor> lista = response.body();
                if (lista != null) {
                    adapter.setDoctores(lista);
                }
            }

            @Override
            public void onFailure(Call<List<Doctor>> call, Throwable t) {
                if (getContext() != null) {
                    Toast.makeText(getContext(), "Error al conectar con el servidor", Toast.LENGTH_LONG).show();
                }
                Log.e("API", "Fallo de conexión: " + t.getMessage());
            }
        });
    }
}
