package com.example.proyectohospital.modelos;

 public class ContadorNotificacionesResponse {
    public int idPaciente;
    public  int totalNoLeidas;

    public ContadorNotificacionesResponse() {
    }

    public ContadorNotificacionesResponse(int idPaciente, int totalNoLeidas) {
        this.idPaciente = idPaciente;
        this.totalNoLeidas = totalNoLeidas;
    }

    public int getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public int getTotalNoLeidas() {
        return totalNoLeidas;
    }

    public void setTotalNoLeidas(int totalNoLeidas) {
        this.totalNoLeidas = totalNoLeidas;
    }

    @Override
    public String toString() {
        return "ContadorNotificacionesResponse{" +
                "idPaciente=" + idPaciente +
                ", totalNoLeidas=" + totalNoLeidas +
                '}';
    }
}