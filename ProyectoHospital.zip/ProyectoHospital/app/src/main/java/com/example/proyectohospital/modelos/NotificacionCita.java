package com.example.proyectohospital.modelos;

import java.util.regex.Pattern;

public class NotificacionCita {
    private int idNotificacion;
    private int idCita;
    private int idPaciente;
    private String tipo; // recordatorio, confirmacion, cambio, cancelacion
    private String mensaje;
    private boolean leida;
    private String fechaCita;
    private String horaCita;
    private String nombreDoctor;
    private String apellidoDoctor;
    private String especialidad;
    private long fechaCreacion;

    public NotificacionCita() {}

    public NotificacionCita(int idNotificacion, int idPaciente, int idCita, String tipo,
                            String mensaje, boolean leida, String fechaCita,
                            String horaCita, String nombreDoctor, String apellidoDoctor) {
        this.idNotificacion = idNotificacion;
        this.idCita = idCita;
        this.tipo = tipo;
        this.mensaje = mensaje;
        this.leida = leida;
        this.idPaciente = idPaciente;
        this.fechaCita = fechaCita;
        this.horaCita = normalizarHora(horaCita);
        this.nombreDoctor = nombreDoctor;
        this.apellidoDoctor = apellidoDoctor;
    }

    public NotificacionCita(int idNotificacion, int idPaciente, int idCita, String tipo,
                            String mensaje, boolean leida, String fechaCita,
                            String horaCita, String nombreDoctor, String apellidoDoctor,
                            String especialidad) {
        this(idNotificacion, idPaciente, idCita, tipo, mensaje, leida, fechaCita,
                horaCita, nombreDoctor, apellidoDoctor);
        this.especialidad = especialidad;
    }

    // ========== GETTERS Y SETTERS ==========

    public int getIdNotificacion() {
        return idNotificacion;
    }

    public void setIdNotificacion(int idNotificacion) {
        this.idNotificacion = idNotificacion;
    }

    public int getIdCita() {
        return idCita;
    }

    public void setIdCita(int idCita) {
        this.idCita = idCita;
    }

    public int getIdPaciente() {
        return idPaciente;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public boolean isLeida() {
        return leida;
    }

    public void setLeida(boolean leida) {
        this.leida = leida;
    }

    public String getFechaCita() {
        return fechaCita;
    }

    public void setFechaCita(String fechaCita) {
        this.fechaCita = fechaCita;
    }

    public String getHoraCita() {
        return horaCita;
    }

    public void setHoraCita(String horaCita) {
        this.horaCita = normalizarHora(horaCita);
    }

    public String getNombreDoctor() {
        return nombreDoctor;
    }

    public void setNombreDoctor(String nombreDoctor) {
        this.nombreDoctor = nombreDoctor;
    }

    public String getApellidoDoctor() {
        return apellidoDoctor;
    }

    public void setApellidoDoctor(String apellidoDoctor) {
        this.apellidoDoctor = apellidoDoctor;
    }

    public String getEspecialidad() {
        return especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public long getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(long fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    // ========== MÉTODOS ÚTILES ==========

    /**
     * Convierte el formato ISO 8601 (PT14H30M) a formato legible (14:30)
     * Ejemplos:
     * - PT11H → 11:00
     * - PT14H30M → 14:30
     * - PT9H → 09:00
     * - 14:30 → 14:30 (ya está en formato correcto)
     */
    private static String normalizarHora(String hora) {
        if (hora == null || hora.isEmpty()) {
            return "00:00";
        }

        // Si ya está en formato HH:MM, retornar tal cual
        if (Pattern.matches("\\d{1,2}:\\d{2}", hora)) {
            return hora;
        }

        // Si está en formato ISO 8601 (PT...)
        if (hora.startsWith("PT")) {
            try {
                // Remover "PT"
                String time = hora.substring(2);

                // Extraer horas
                int horasValue = 0;
                int minutosValue = 0;

                if (time.contains("H")) {
                    int hIndex = time.indexOf("H");
                    String horasStr = time.substring(0, hIndex);
                    horasValue = Integer.parseInt(horasStr);
                    time = time.substring(hIndex + 1);
                }

                if (time.contains("M")) {
                    int mIndex = time.indexOf("M");
                    String minutosStr = time.substring(0, mIndex);
                    if (!minutosStr.isEmpty()) {
                        minutosValue = Integer.parseInt(minutosStr);
                    }
                }

                // Retornar en formato HH:MM
                return String.format("%02d:%02d", horasValue, minutosValue);
            } catch (Exception e) {
                // Si hay error en parsing, retornar la hora original
                return hora;
            }
        }

        // Si no reconoce el formato, devolver tal cual
        return hora;
    }

    public String getNombreCompletoDoctor() {
        return nombreDoctor + " " + apellidoDoctor;
    }

    public String getEmojiTipo() {
        switch (tipo) {
            case "recordatorio":
                return "🔔";
            case "confirmacion":
                return "✓";
            case "cambio":
                return "🔄";
            case "cancelacion":
                return "✗";
            default:
                return "📋";
        }
    }

    public String getTituloTipo() {
        switch (tipo) {
            case "recordatorio":
                return "Recordatorio de cita";
            case "confirmacion":
                return "Cita confirmada";
            case "cambio":
                return "Cita reprogramada";
            case "cancelacion":
                return "Cita cancelada";
            default:
                return "Notificación de cita";
        }
    }
}