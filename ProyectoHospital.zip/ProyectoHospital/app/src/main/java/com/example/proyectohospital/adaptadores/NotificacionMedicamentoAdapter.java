package com.example.proyectohospital.adaptadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.proyectohospital.R;
import com.example.proyectohospital.modelos.NotificacionMedicamento;
import java.util.ArrayList;
import java.util.List;

public class NotificacionMedicamentoAdapter extends RecyclerView.Adapter<NotificacionMedicamentoAdapter.NotificacionViewHolder> {

    private List<NotificacionMedicamento> notificaciones;
    private OnNotificacionListener listener;

    public interface OnNotificacionListener {
        void onMarcarTomado(NotificacionMedicamento notificacion, int position);
        void onPosponer(NotificacionMedicamento notificacion, int position);
        void onNotificacionClick(NotificacionMedicamento notificacion, int position);
    }

    public NotificacionMedicamentoAdapter(OnNotificacionListener listener) {
        this.notificaciones = new ArrayList<>();
        this.listener = listener;
    }

    public void setNotificaciones(List<NotificacionMedicamento> notificaciones) {
        this.notificaciones = notificaciones;
        notifyDataSetChanged();
    }

    public void removeNotificacion(int position) {
        if (position >= 0 && position < notificaciones.size()) {
            notificaciones.remove(position);
            notifyItemRemoved(position);
        }
    }

    public void updateNotificacion(int position) {
        if (position >= 0 && position < notificaciones.size()) {
            notifyItemChanged(position);
        }
    }

    @NonNull
    @Override
    public NotificacionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_notificacion_medicamento, parent, false);
        return new NotificacionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NotificacionViewHolder holder, int position) {
        NotificacionMedicamento notif = notificaciones.get(position);

        holder.tvNombreMedicamento.setText(notif.getNombreMedicamento());
        holder.tvDosis.setText(notif.getDosis());
        holder.tvHoraToma.setText(notif.getHoraToma());
        holder.tvTiempoTranscurrido.setText(notif.getTiempoTranscurrido());

        // Mostrar u ocultar indicador de no leída
        holder.indicatorUnread.setVisibility(notif.isLeida() ? View.GONE : View.VISIBLE);

        // Cambiar apariencia si ya fue tomado
        if (notif.isTomado()) {
            holder.btnTomado.setText("✓ Tomado");
            holder.btnTomado.setEnabled(false);
            holder.btnPosponer.setVisibility(View.GONE);
            holder.itemView.setAlpha(0.6f);
        } else {
            holder.btnTomado.setText("Marcar como tomado");
            holder.btnTomado.setEnabled(true);
            holder.btnPosponer.setVisibility(View.VISIBLE);
            holder.itemView.setAlpha(1.0f);
        }

        // Click en el item completo
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                notif.setLeida(true);
                holder.indicatorUnread.setVisibility(View.GONE);
                listener.onNotificacionClick(notif, holder.getAdapterPosition());
            }
        });

        // Click en botón "Marcar como tomado"
        holder.btnTomado.setOnClickListener(v -> {
            if (listener != null && !notif.isTomado()) {
                listener.onMarcarTomado(notif, holder.getAdapterPosition());
            }
        });

        // Click en botón "Posponer"
        holder.btnPosponer.setOnClickListener(v -> {
            if (listener != null) {
                listener.onPosponer(notif, holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return notificaciones.size();
    }

    static class NotificacionViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombreMedicamento, tvDosis, tvHoraToma, tvTiempoTranscurrido;
        TextView btnTomado, btnPosponer;
        View indicatorUnread;

        public NotificacionViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombreMedicamento = itemView.findViewById(R.id.tvMedicamentoNombre);
            tvDosis = itemView.findViewById(R.id.tvMedicamentoDosis);
            tvHoraToma = itemView.findViewById(R.id.tvHoraToma);
            tvTiempoTranscurrido = itemView.findViewById(R.id.tvTiempoTranscurrido);
            btnTomado = itemView.findViewById(R.id.btn_tomado);
            btnPosponer = itemView.findViewById(R.id.btn_posponer);
            indicatorUnread = itemView.findViewById(R.id.indicator_unread);
        }
    }
}