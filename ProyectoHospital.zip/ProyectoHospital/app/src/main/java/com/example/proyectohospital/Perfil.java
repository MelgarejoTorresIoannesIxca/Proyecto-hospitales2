package com.example.proyectohospital;

import android.app.Activity;

public class Perfil extends Activity {
}
