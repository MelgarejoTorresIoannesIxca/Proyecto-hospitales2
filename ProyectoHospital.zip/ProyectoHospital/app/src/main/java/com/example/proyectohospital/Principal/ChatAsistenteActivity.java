package com.example.proyectohospital.Principal;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectohospital.MainActivity;
import com.example.proyectohospital.R;
import com.example.proyectohospital.adaptadores.ChatMensajeAdapter;
import com.example.proyectohospital.adaptadores.ChatSugerenciaAdapter;
import com.example.proyectohospital.modelos.ChatMensaje;
import com.example.proyectohospital.modelos.ChatSugerencia;
import com.example.proyectohospital.modelos.EnviarMensajeRequest;
import com.example.proyectohospital.modelos.EnviarMensajeResponse;
import com.example.proyectohospital.navegacion.ApiService;
import com.example.proyectohospital.navegacion.RetrofitClient;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChatAsistenteActivity extends AppCompatActivity
        implements ChatMensajeAdapter.OnMensajeListener,
        ChatSugerenciaAdapter.OnSugerenciaClickListener {

    private static final String TAG = "ChatAsistente";

    private RecyclerView recyclerMensajes, recyclerSugerencias;
    private ChatMensajeAdapter mensajeAdapter;
    private ChatSugerenciaAdapter sugerenciaAdapter;
    private EditText etMensaje;
    private ImageView btnEnviar, btnBack, btnLimpiar;
    private LinearLayout emptyState;

    private ApiService apiService;
    private int idPaciente;
    private int idConversacion = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_asistente);

        idPaciente = getIntent().getIntExtra("id_paciente", 21);
        if (idPaciente == -1) {
            Toast.makeText(this, "Error: ID de paciente no válido", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        inicializarVistas();
        configurarAdaptadores();
        configurarListeners();

        apiService = RetrofitClient.getClient().create(ApiService.class);

        cargarConversacion();
        cargarSugerencias();
    }

    private void inicializarVistas() {
        recyclerMensajes = findViewById(R.id.recycler_mensajes);
        recyclerSugerencias = findViewById(R.id.recycler_sugerencias);
        etMensaje = findViewById(R.id.et_mensaje);
        btnEnviar = findViewById(R.id.btn_enviar);
        btnBack = findViewById(R.id.btn_back_chat);
        btnLimpiar = findViewById(R.id.btn_limpiar_chat);
        emptyState = findViewById(R.id.empty_state_chat);
    }

    private void configurarAdaptadores() {
        // Adapter de mensajes
        mensajeAdapter = new ChatMensajeAdapter(this);
        recyclerMensajes.setLayoutManager(new LinearLayoutManager(this));
        recyclerMensajes.setAdapter(mensajeAdapter);

        // Adapter de sugerencias (horizontal)
        sugerenciaAdapter = new ChatSugerenciaAdapter(this);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this,
                LinearLayoutManager.HORIZONTAL, false);
        recyclerSugerencias.setLayoutManager(layoutManager);
        recyclerSugerencias.setAdapter(sugerenciaAdapter);
    }

    private void configurarListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnEnviar.setOnClickListener(v -> enviarMensaje());

        btnLimpiar.setOnClickListener(v -> {
            mensajeAdapter.limpiarMensajes();
            mostrarEstadoVacio(true);
            Toast.makeText(this, "Chat limpiado", Toast.LENGTH_SHORT).show();
        });
    }

    private void cargarConversacion() {
        Log.d(TAG, "Cargando conversación para paciente: " + idPaciente);

        apiService.getConversacionPaciente(idPaciente).enqueue(new Callback<ConversacionResponse>() {
            @Override
            public void onResponse(Call<ConversacionResponse> call, Response<ConversacionResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    ConversacionResponse conversacion = response.body();
                    idConversacion = conversacion.getConversacion().getIdConversacion();
                    Log.d(TAG, "Conversación obtenida: " + idConversacion);

                    cargarMensajes(idConversacion);
                } else {
                    Log.e(TAG, "Error al obtener conversación: " + response.code());
                    Toast.makeText(ChatAsistenteActivity.this,
                            "Error al cargar conversación", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ConversacionResponse> call, Throwable t) {
                Log.e(TAG, "Error de red: " + t.getMessage());
                Toast.makeText(ChatAsistenteActivity.this,
                        "Error de conexión", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void cargarMensajes(int idConversacion) {
        Log.d(TAG, "Cargando mensajes de conversación: " + idConversacion);

        apiService.getMensajesConversacion(idConversacion, 50).enqueue(new Callback<List<ChatMensaje>>() {
            @Override
            public void onResponse(Call<List<ChatMensaje>> call, Response<List<ChatMensaje>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<ChatMensaje> mensajes = response.body();
                    Log.d(TAG, "Mensajes cargados: " + mensajes.size());

                    mensajeAdapter.setMensajes(mensajes);
                    mostrarEstadoVacio(mensajes.isEmpty());

                    if (!mensajes.isEmpty()) {
                        recyclerMensajes.scrollToPosition(mensajes.size() - 1);
                    }
                } else {
                    Log.e(TAG, "Error al cargar mensajes: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<List<ChatMensaje>> call, Throwable t) {
                Log.e(TAG, "Error al cargar mensajes: " + t.getMessage());
            }
        });
    }

    private void cargarSugerencias() {
        Log.d(TAG, "Cargando sugerencias para paciente: " + idPaciente);

        apiService.getSugerenciasPersonalizadas(idPaciente).enqueue(new Callback<List<ChatSugerencia>>() {
            @Override
            public void onResponse(Call<List<ChatSugerencia>> call, Response<List<ChatSugerencia>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<ChatSugerencia> sugerencias = response.body();
                    Log.d(TAG, "Sugerencias cargadas: " + sugerencias.size());
                    sugerenciaAdapter.setSugerencias(sugerencias);
                } else {
                    Log.e(TAG, "Error al cargar sugerencias: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<List<ChatSugerencia>> call, Throwable t) {
                Log.e(TAG, "Error al cargar sugerencias: " + t.getMessage());
            }
        });
    }

    private void enviarMensaje() {
        String contenido = etMensaje.getText().toString().trim();

        if (contenido.isEmpty()) {
            Toast.makeText(this, "Escribe un mensaje", Toast.LENGTH_SHORT).show();
            return;
        }

        // Limpiar input
        etMensaje.setText("");

        // Crear mensaje local temporalmente
        ChatMensaje mensajeUsuario = new ChatMensaje("usuario", contenido);
        mensajeAdapter.agregarMensaje(mensajeUsuario);
        recyclerMensajes.scrollToPosition(mensajeAdapter.getItemCount() - 1);
        mostrarEstadoVacio(false);

        // Enviar a la API
        EnviarMensajeRequest request = new EnviarMensajeRequest(idPaciente, contenido);

        apiService.enviarMensaje(request).enqueue(new Callback<EnviarMensajeResponse>() {
            @Override
            public void onResponse(Call<EnviarMensajeResponse> call, Response<EnviarMensajeResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    EnviarMensajeResponse respuesta = response.body();

                    // Agregar respuesta del asistente
                    ChatMensaje mensajeAsistente = new ChatMensaje("asistente",
                            respuesta.getMensajeAsistente().getContenido());
                    mensajeAsistente.setTipoSugerencia(respuesta.getMensajeAsistente().getTipoSugerencia());

                    mensajeAdapter.agregarMensaje(mensajeAsistente);
                    recyclerMensajes.scrollToPosition(mensajeAdapter.getItemCount() - 1);

                    // Recargar sugerencias
                    cargarSugerencias();
                } else {
                    Log.e(TAG, "Error al enviar mensaje: " + response.code());
                    Toast.makeText(ChatAsistenteActivity.this,
                            "Error al enviar mensaje", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<EnviarMensajeResponse> call, Throwable t) {
                Log.e(TAG, "Error de red: " + t.getMessage());
                Toast.makeText(ChatAsistenteActivity.this,
                        "Error de conexión", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void mostrarEstadoVacio(boolean vacio) {
        if (vacio) {
            emptyState.setVisibility(View.VISIBLE);
            recyclerMensajes.setVisibility(View.GONE);
        } else {
            emptyState.setVisibility(View.GONE);
            recyclerMensajes.setVisibility(View.VISIBLE);
        }
    }

    // ========== Callbacks de Adaptadores ==========

    @Override
    public void onAccionRapida(ChatMensaje mensaje, String accion) {
        Log.d(TAG, "Acción rápida: " + accion);

        switch (accion) {
            case "ver_medicamentos":
                // Navegar a la pantalla de medicamentos
                Intent intentMeds = new Intent(this, MainActivity.class);
                intentMeds.putExtra("id_paciente", idPaciente);
                intentMeds.putExtra("fragmento", "medicamentos");
                startActivity(intentMeds);
                break;

            case "ver_citas":
                // Navegar a la pantalla de citas
                Intent intentCitas = new Intent(this, activity_notificaciones.class);
                intentCitas.putExtra("id_paciente", idPaciente);
                startActivity(intentCitas);
                break;

            case "agendar_cita":
                // Navegar a agendar cita
                Intent intentAgendar = new Intent(this, ListaDoctoresActivity.class);
                intentAgendar.putExtra("id_paciente", idPaciente);
                startActivity(intentAgendar);
                break;

            case "configurar_recordatorios":
                Toast.makeText(this, "Configurar recordatorios", Toast.LENGTH_SHORT).show();
                break;

            default:
                Toast.makeText(this, "Acción: " + accion, Toast.LENGTH_SHORT).show();
                break;
        }
    }

    @Override
    public void onSugerenciaClick(ChatSugerencia sugerencia) {
        Log.d(TAG, "Sugerencia clickeada: " + sugerencia.getAccion());

        // Enviar mensaje basado en la sugerencia
        String mensaje = "Hola, " + sugerencia.getTitulo().toLowerCase();
        etMensaje.setText(mensaje);
        enviarMensaje();

        // O ejecutar acción directamente
        onAccionRapida(null, sugerencia.getAccion());
    }

    // ========== Clase auxiliar para respuesta de conversación ==========
    public static class ConversacionResponse {
        private String status;
        private ChatConversacion conversacion;

        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }

        public ChatConversacion getConversacion() { return conversacion; }
        public void setConversacion(ChatConversacion conversacion) {
            this.conversacion = conversacion;
        }
    }

    // Importar ChatConversacion del paquete de modelos
    private static class ChatConversacion {
        private int idConversacion;
        private int idPaciente;
        private String fechaCreacion;

        public int getIdConversacion() { return idConversacion; }
        public void setIdConversacion(int idConversacion) {
            this.idConversacion = idConversacion;
        }

        public int getIdPaciente() { return idPaciente; }
        public void setIdPaciente(int idPaciente) { this.idPaciente = idPaciente; }

        public String getFechaCreacion() { return fechaCreacion; }
        public void setFechaCreacion(String fechaCreacion) {
            this.fechaCreacion = fechaCreacion;
        }
    }
}