package com.example.proyectohospital.Principal;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.bumptech.glide.Glide;
import com.example.proyectohospital.R;


public class Detalle_Doctores extends AppCompatActivity {

    ImageView imgDoctor;
    TextView tvNombre, tvEspecialidades, tvDescripcion, tvRating, tvInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_doctores);

        // IDs del XML que me enviaste
        imgDoctor = findViewById(R.id.imgDoctor);
        tvNombre = findViewById(R.id.tvDoctorName);
        tvEspecialidades = findViewById(R.id.tvSpecialty);
        tvRating = findViewById(R.id.tvRating);
        tvInfo = findViewById(R.id.tvDoctorInfo);

        // Recuperar datos enviados desde el adapter
        Intent i = getIntent();
        String nombre = i.getStringExtra("nombre");
        String especialidad = i.getStringExtra("especialidad");
        String descripcion = i.getStringExtra("descripcion");
        String foto = i.getStringExtra("foto");
        double calificacion = i.getDoubleExtra("calificacion", 0.0);

        // Pintar información
        tvNombre.setText(nombre);
        tvEspecialidades.setText(especialidad);
        tvRating.setText("⭐ " + calificacion);

        // Si no tienes descripción, usa la info de tu XML
        if (descripcion != null && !descripcion.isEmpty()) {
            tvInfo.setText(descripcion);
        }

        // Carga la imagen con Glide
        if (foto != null && foto.length() > 4) {
            Glide.with(this).load(foto).into(imgDoctor);
        }
    }
}
