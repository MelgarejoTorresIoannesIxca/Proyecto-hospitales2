package com.example.proyectohospital.modelos;
public class Cita {
    private int idCita;
    private int idPaciente;
    private int idDoctor;
    private String fechaCita;
    private String horaCita;
    private String estado; // pendiente, confirmada, completada, cancelada
    private String motivo;
    private String lugarConsulta;
    private String nombreDoctor;
    private String apellidoDoctor;
    private String especialidad;
    private String foto;

    public Cita() {}

    public Cita(int idCita, int idPaciente, int idDoctor, String fechaCita,
                String horaCita, String estado, String motivo, String nombreDoctor,
                String apellidoDoctor, String especialidad) {
        this.idCita = idCita;
        this.idPaciente = idPaciente;
        this.idDoctor = idDoctor;
        this.fechaCita = fechaCita;
        this.horaCita = horaCita;
        this.estado = estado;
        this.motivo = motivo;
        this.nombreDoctor = nombreDoctor;
        this.apellidoDoctor = apellidoDoctor;
        this.especialidad = especialidad;
    }

    // Getters y Setters
    public int getIdCita() { return idCita; }
    public void setIdCita(int idCita) { this.idCita = idCita; }

    public int getIdPaciente() { return idPaciente; }
    public void setIdPaciente(int idPaciente) { this.idPaciente = idPaciente; }

    public int getIdDoctor() { return idDoctor; }
    public void setIdDoctor(int idDoctor) { this.idDoctor = idDoctor; }

    public String getFechaCita() { return fechaCita; }
    public void setFechaCita(String fechaCita) { this.fechaCita = fechaCita; }

    public String getHoraCita() { return horaCita; }
    public void setHoraCita(String horaCita) { this.horaCita = horaCita; }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }

    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }

    public String getLugarConsulta() { return lugarConsulta; }
    public void setLugarConsulta(String lugarConsulta) { this.lugarConsulta = lugarConsulta; }

    public String getNombreDoctor() { return nombreDoctor; }
    public void setNombreDoctor(String nombreDoctor) { this.nombreDoctor = nombreDoctor; }

    public String getApellidoDoctor() { return apellidoDoctor; }
    public void setApellidoDoctor(String apellidoDoctor) { this.apellidoDoctor = apellidoDoctor; }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public String getFoto() { return foto; }
    public void setFoto(String foto) { this.foto = foto; }
}