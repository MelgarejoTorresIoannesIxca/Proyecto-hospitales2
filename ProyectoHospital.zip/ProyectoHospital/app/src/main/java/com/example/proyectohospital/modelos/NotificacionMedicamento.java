    package com.example.proyectohospital.modelos;

    public class NotificacionMedicamento {
        private int id;
        private String nombreMedicamento;
        private String dosis;
        private String horaToma;
        private long timestamp;
        private boolean leida;
        private boolean tomado;
        private int idPaciente;

        public NotificacionMedicamento() {
        }

        public NotificacionMedicamento(int id, String nombreMedicamento, String dosis,
                                       String horaToma, long timestamp, int idPaciente) {
            this.id = id;
            this.nombreMedicamento = nombreMedicamento;
            this.dosis = dosis;
            this.horaToma = horaToma;
            this.timestamp = timestamp;
            this.leida = false;
            this.tomado = false;
            this.idPaciente = idPaciente;
        }

        // Getters
        public int getId() {
            return id;
        }

        public String getNombreMedicamento() {
            return nombreMedicamento;
        }

        public String getDosis() {
            return dosis;
        }

        public String getHoraToma() {
            return horaToma;
        }

        public long getTimestamp() {
            return timestamp;
        }

        public boolean isLeida() {
            return leida;
        }

        public boolean isTomado() {
            return tomado;
        }

        public int getIdPaciente() {
            return idPaciente;
        }

        // Setters
        public void setId(int id) {
            this.id = id;
        }

        public void setNombreMedicamento(String nombreMedicamento) {
            this.nombreMedicamento = nombreMedicamento;
        }

        public void setDosis(String dosis) {
            this.dosis = dosis;
        }

        public void setHoraToma(String horaToma) {
            this.horaToma = horaToma;
        }

        public void setTimestamp(long timestamp) {
            this.timestamp = timestamp;
        }

        public void setLeida(boolean leida) {
            this.leida = leida;
        }

        public void setTomado(boolean tomado) {
            this.tomado = tomado;
        }

        public void setIdPaciente(int idPaciente) {
            this.idPaciente = idPaciente;
        }

        // Método para obtener el tiempo transcurrido
        public String getTiempoTranscurrido() {
            long ahora = System.currentTimeMillis();
            long diferencia = ahora - timestamp;

            long minutos = diferencia / (60 * 1000);
            long horas = diferencia / (60 * 60 * 1000);
            long dias = diferencia / (24 * 60 * 60 * 1000);

            if (minutos < 60) {
                return "Hace " + minutos + " min";
            } else if (horas < 24) {
                return "Hace " + horas + " h";
            } else {
                return "Hace " + dias + " días";
            }
        }
    }