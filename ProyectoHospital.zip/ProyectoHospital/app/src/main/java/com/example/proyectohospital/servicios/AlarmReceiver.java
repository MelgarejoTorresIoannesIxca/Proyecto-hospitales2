package com.example.proyectohospital.servicios;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.example.proyectohospital.R;
import com.example.proyectohospital.Principal.activity_notificaciones;
import com.example.proyectohospital.modelos.NotificacionMedicamento;

public class AlarmReceiver extends BroadcastReceiver {

    private static final String TAG = "AlarmReceiver";
    private static final String CHANNEL_ID = "medicamentos_channel";
    private static final String CHANNEL_NAME = "Recordatorios de Medicamentos";
    private static final String CHANNEL_DESC = "Notificaciones para recordar tomar medicamentos";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "AlarmReceiver activado - onReceive()");

        String nombreMedicamento = intent.getStringExtra("nombre_medicamento");
        String dosis = intent.getStringExtra("dosis");
        String horaToma = intent.getStringExtra("hora_toma");
        int idPaciente = intent.getIntExtra("id_paciente", 0);
        int notificationId = intent.getIntExtra("notification_id", 0);

        Log.d(TAG, "Medicamento: " + nombreMedicamento + " - Hora: " + horaToma);

        // Crear la notificación en el sistema
        crearNotificacionSistema(context, nombreMedicamento, dosis, horaToma, notificationId, idPaciente);

        // Guardar la notificación en la base de datos local
        guardarNotificacionLocal(context, nombreMedicamento, dosis, horaToma, idPaciente, notificationId);
    }

    private void crearNotificacionSistema(Context context, String nombreMedicamento,
                                          String dosis, String horaToma, int notificationId, int idPaciente) {
        NotificationManager notificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (notificationManager == null) {
            Log.e(TAG, "NotificationManager es null");
            return;
        }

        // Crear canal de notificación para Android O+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID,
                    CHANNEL_NAME,
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription(CHANNEL_DESC);
            channel.enableLights(true);
            channel.setLightColor(Color.BLUE);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            channel.setShowBadge(true);
            notificationManager.createNotificationChannel(channel);
            Log.d(TAG, "Canal de notificación creado");
        }

        // Intent para abrir la pantalla de notificaciones al hacer click
        Intent intent = new Intent(context, activity_notificaciones.class);
        intent.putExtra("id_paciente", idPaciente);
        intent.putExtra("notification_id", notificationId);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                notificationId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        // Sonido de notificación
        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        // Construir la notificación
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_pill)  // Asegúrate de tener este icono
                .setContentTitle("💊 Recordatorio de Medicamento")
                .setContentText(nombreMedicamento + " - " + dosis)
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText("Es hora de tomar:\n" + nombreMedicamento + "\n\nDosis: " + dosis + "\nHora: " + horaToma))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setSound(soundUri)
                .setVibrate(new long[]{0, 1000, 500, 1000})
                .setLights(Color.BLUE, 3000, 3000)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .addAction(R.drawable.ic_check_all, "Tomado",
                        crearAccionTomado(context, notificationId, idPaciente, nombreMedicamento))
                .addAction(R.drawable.ic_clock, "Posponer",
                        crearAccionPosponer(context, notificationId, nombreMedicamento, dosis, horaToma, idPaciente));

        // Mostrar la notificación
        notificationManager.notify(notificationId, builder.build());
        Log.d(TAG, "Notificación mostrada - ID: " + notificationId);
    }

    private PendingIntent crearAccionTomado(Context context, int notificationId, int idPaciente, String nombreMedicamento) {
        Intent intent = new Intent(context, NotificacionActionReceiver.class);
        intent.setAction("ACTION_TOMADO");
        intent.putExtra("notification_id", notificationId);
        intent.putExtra("id_paciente", idPaciente);
        intent.putExtra("nombre_medicamento", nombreMedicamento);

        return PendingIntent.getBroadcast(
                context,
                notificationId * 10 + 1,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private PendingIntent crearAccionPosponer(Context context, int notificationId,
                                              String nombreMedicamento, String dosis,
                                              String horaToma, int idPaciente) {
        Intent intent = new Intent(context, NotificacionActionReceiver.class);
        intent.setAction("ACTION_POSPONER");
        intent.putExtra("notification_id", notificationId);
        intent.putExtra("nombre_medicamento", nombreMedicamento);
        intent.putExtra("dosis", dosis);
        intent.putExtra("hora_toma", horaToma);
        intent.putExtra("id_paciente", idPaciente);

        return PendingIntent.getBroadcast(
                context,
                notificationId * 10 + 2,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );
    }

    private void guardarNotificacionLocal(Context context, String nombreMedicamento,
                                          String dosis, String horaToma, int idPaciente, int notificationId) {
        com.example.proyectohospital.servicios.NotificacionManager notifManager =
                new com.example.proyectohospital.servicios.NotificacionManager(context);

        NotificacionMedicamento notificacion = new NotificacionMedicamento(
                notificationId,
                nombreMedicamento,
                dosis,
                horaToma,
                System.currentTimeMillis(),
                idPaciente
        );

        notifManager.agregarNotificacion(notificacion);
        Log.d(TAG, "Notificación guardada localmente - ID: " + notificationId);
    }
}