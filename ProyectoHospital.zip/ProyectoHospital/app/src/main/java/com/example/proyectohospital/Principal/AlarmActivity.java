package com.example.proyectohospital.Principal;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Vibrator;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.example.proyectohospital.R;
import com.example.proyectohospital.servicios.NotificacionActionReceiver;

public class AlarmActivity extends AppCompatActivity {

    private MediaPlayer mediaPlayer;
    private Vibrator vibrator;

    private String nombreMedicamento;
    private String dosis;
    private String horaToma;
    private int idPaciente;
    private int notificationId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);

        // Hace que la pantalla se encienda aunque esté bloqueada
        getWindow().addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON |
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
        );

        // Obtener datos enviados desde la notificación
        nombreMedicamento = getIntent().getStringExtra("nombre_medicamento");
        dosis = getIntent().getStringExtra("dosis");
        horaToma = getIntent().getStringExtra("hora_toma");
        idPaciente = getIntent().getIntExtra("id_paciente", -1);
        notificationId = getIntent().getIntExtra("notification_id", 0);

        // Mostrar en pantalla
        ((TextView) findViewById(R.id.txtNombreMedicamento)).setText(nombreMedicamento);
        ((TextView) findViewById(R.id.txtDosis)).setText("Dosis: " + dosis);
        ((TextView) findViewById(R.id.txtHoraToma)).setText("Programada a las: " + horaToma);

        // Botones
        Button btnDetener = findViewById(R.id.btnDetener);
        Button btnPosponer = findViewById(R.id.btnPosponer);

        btnDetener.setOnClickListener(v -> detenerAlarma());
        btnPosponer.setOnClickListener(v -> posponerAlarma());

        // Iniciar sonido y vibración
        iniciarAlarma();
    }

    // 🔊 Iniciar sonido + vibración
    private void iniciarAlarma() {
        // Subir volumen al máximo
        AudioManager audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        audio.setStreamVolume(AudioManager.STREAM_ALARM,
                audio.getStreamMaxVolume(AudioManager.STREAM_ALARM),
                AudioManager.FLAG_PLAY_SOUND);

        // Reproducir sonido de alarma
        Uri tono = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        mediaPlayer = new MediaPlayer();
        try {
            mediaPlayer.setAudioAttributes(
                    new AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_ALARM)
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .build()
            );
            mediaPlayer.setDataSource(this, tono);
            mediaPlayer.setLooping(true);
            mediaPlayer.prepare();
            mediaPlayer.start();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Vibración
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        long[] pattern = {0, 800, 500};
        vibrator.vibrate(pattern, 0);
    }

    // 🛑 Detener alarma
    private void detenerAlarma() {
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
        }
        if (vibrator != null) vibrator.cancel();

        finish();
    }

    // ⏰ Posponer alarma 5 minutos
    private void posponerAlarma() {

        long tiempo = System.currentTimeMillis() + (5 * 60 * 1000);

        Intent i = new Intent(this, NotificacionActionReceiver.class);
        i.putExtra("nombre_medicamento", nombreMedicamento);
        i.putExtra("dosis", dosis);
        i.putExtra("hora_toma", horaToma);
        i.putExtra("id_paciente", idPaciente);
        i.putExtra("notification_id", notificationId);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                notificationId,
                i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        alarmManager.setExact(AlarmManager.RTC_WAKEUP, tiempo, pendingIntent);

        detenerAlarma();  // apaga sonido
        finish();         // cierra actividad
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        if (vibrator != null) vibrator.cancel();
    }
}
