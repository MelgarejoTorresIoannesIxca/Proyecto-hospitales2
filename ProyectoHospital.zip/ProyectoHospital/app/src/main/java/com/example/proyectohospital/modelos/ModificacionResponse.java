package com.example.proyectohospital.modelos;

public class ModificacionResponse {
}
