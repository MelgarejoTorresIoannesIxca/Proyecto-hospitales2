package com.example.proyectohospital.modelos;

public class MensajeResponse {
    private String status;
    private String mensaje;

    // Constructor vacío
    public MensajeResponse() {
    }

    // Constructor con parámetros
    public MensajeResponse(String status, String mensaje) {
        this.status = status;
        this.mensaje = mensaje;
    }

    // Getters
    public String getStatus() {
        return status;
    }

    public String getMensaje() {
        return mensaje;
    }

    // Setters
    public void setStatus(String status) {
        this.status = status;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    @Override
    public String toString() {
        return "MensajeResponse{" +
                "status='" + status + '\'' +
                ", mensaje='" + mensaje + '\'' +
                '}';
    }
}