package com.example.proyectohospital.InicioSesion;

import android.Manifest;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.LinearLayout;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;

import com.example.proyectohospital.Principal.MainPrincipalCliente;
import com.example.proyectohospital.R;

import java.util.concurrent.Executor;

public class UsuarioIniciado extends AppCompatActivity {

    private static final String TAG = "UsuarioIniciado";
    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "SesionUsuario";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_TOKEN = "token";

    private TextView tvSecurityMessage;
    private LinearLayout btnLoginFingerprint, btnLoginPassword;

    // Launcher para permisos de notificaciones
    private ActivityResultLauncher<String> requestPermissionLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_usuario_iniciado);

        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        tvSecurityMessage = findViewById(R.id.tvSecurityMessage);
        btnLoginFingerprint = findViewById(R.id.btnLoginFingerprint);
        btnLoginPassword = findViewById(R.id.btnLoginPassword);

        String email = sharedPreferences.getString(KEY_EMAIL, "usuario");
        tvSecurityMessage.setText("Bienvenido " + email + ", por tu seguridad, cerramos la sesión cada 5 minutos si no hay actividad. Puedes ingresar con las siguientes formas:");

        btnLoginFingerprint.setOnClickListener(v -> autenticarConHuella());
        btnLoginPassword.setOnClickListener(v -> {
            // Eliminar token para forzar login manual
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.remove(KEY_TOKEN);
            editor.apply();
            startActivity(new Intent(this, InicioSesion.class));
            finish();
        });

        // Inicializar y solicitar permisos de notificaciones
        inicializarLauncherPermisos();
        solicitarPermisosNotificaciones();
    }

    private void autenticarConHuella() {
        BiometricManager biometricManager = BiometricManager.from(this);
        switch (biometricManager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG)) {
            case BiometricManager.BIOMETRIC_SUCCESS:
                mostrarPromptBiometrico();
                break;
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                // Si no hay huella disponible o no está registrada → ir a login normal
                startActivity(new Intent(this, InicioSesion.class));
                finish();
                break;
        }
    }

    private void mostrarPromptBiometrico() {
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt biometricPrompt = new BiometricPrompt(this, executor,
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        // Autenticación correcta → ir a la pantalla principal
                        startActivity(new Intent(UsuarioIniciado.this, MainPrincipalCliente.class));
                        finish();
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, CharSequence errString) {
                        super.onAuthenticationError(errorCode, errString);
                        // Error de huella → ir a login normal
                        startActivity(new Intent(UsuarioIniciado.this, InicioSesion.class));
                        finish();
                    }

                    @Override
                    public void onAuthenticationFailed() {
                        super.onAuthenticationFailed();
                        // Si falla, simplemente muestra un toast (opcional)
                    }
                });

        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Autenticación biométrica")
                .setSubtitle("Usa tu huella para ingresar nuevamente")
                .setNegativeButtonText("Cancelar")
                .build();

        biometricPrompt.authenticate(promptInfo);
    }

    // ========== MÉTODOS PARA PERMISOS DE NOTIFICACIONES ==========

    /**
     * Inicializa el launcher para solicitar permisos de notificaciones
     */
    private void inicializarLauncherPermisos() {
        requestPermissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                isGranted -> {
                    if (isGranted) {
                        Log.d(TAG, "✓ Permiso de notificaciones concedido");
                        Toast.makeText(this, "✓ Recibirás recordatorios de medicamentos", Toast.LENGTH_SHORT).show();
                    } else {
                        Log.w(TAG, "✗ Permiso de notificaciones denegado");
                        // Mostrar mensaje informativo suave (no bloquear al usuario)
                        Toast.makeText(this, "💡 Puedes activar notificaciones después en ajustes", Toast.LENGTH_SHORT).show();
                    }
                }
        );
    }

    /**
     * Solicita permisos de notificaciones (solo para Android 13+)
     */
    private void solicitarPermisosNotificaciones() {
        // Solo para Android 13+ (API 33+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {

                Log.d(TAG, "Solicitando permiso de notificaciones...");

                // Verificar si debemos mostrar una explicación
                if (shouldShowRequestPermissionRationale(Manifest.permission.POST_NOTIFICATIONS)) {
                    // Si el usuario rechazó antes, mostrar diálogo explicativo
                    mostrarDialogoExplicativo();
                } else {
                    // Primera vez, solicitar directamente
                    requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
                }
            } else {
                Log.d(TAG, "✓ Permiso de notificaciones ya concedido");
            }
        } else {
            Log.d(TAG, "Android < 13, no se requiere solicitar permiso POST_NOTIFICATIONS");
        }
    }

    /**
     * Muestra un diálogo explicando por qué necesitamos el permiso
     */
    private void mostrarDialogoExplicativo() {
        new AlertDialog.Builder(this)
                .setTitle("🔔 Recordatorios de Medicamentos")
                .setMessage("Para ayudarte a tomar tus medicamentos a tiempo, necesitamos enviarte notificaciones.\n\n" +
                        "¿Deseas activar las notificaciones?")
                .setPositiveButton("Sí, activar", (dialog, which) -> {
                    requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
                })
                .setNegativeButton("Ahora no", (dialog, which) -> {
                    Log.d(TAG, "Usuario rechazó permisos de notificaciones");
                })
                .setCancelable(true)
                .show();
    }

    /**
     * Verifica si las notificaciones están habilitadas
     */
    public boolean tienePermisosNotificaciones() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    == PackageManager.PERMISSION_GRANTED;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            return nm != null && nm.areNotificationsEnabled();
        }
        return true; // Versiones antiguas asumen que están habilitadas
    }

    /**
     * Abre la configuración de la app para que el usuario active notificaciones manualmente
     */
    private void abrirConfiguracionApp() {
        Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        Uri uri = Uri.fromParts("package", getPackageName(), null);
        intent.setData(uri);
        startActivity(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Verificar estado de notificaciones cuando regresa a esta pantalla
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) {
                boolean enabled = nm.areNotificationsEnabled();
                Log.d(TAG, "Estado notificaciones: " + (enabled ? "HABILITADAS ✓" : "DESHABILITADAS ✗"));
            }
        }
    }
}