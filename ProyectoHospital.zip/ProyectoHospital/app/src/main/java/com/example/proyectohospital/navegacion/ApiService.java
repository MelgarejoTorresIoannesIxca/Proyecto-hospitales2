package com.example.proyectohospital.navegacion;

import com.example.proyectohospital.Principal.ChatAsistenteActivity;
import com.example.proyectohospital.modelos.ActualizarNotificacionResponse;
import com.example.proyectohospital.modelos.ChatMensaje;
import com.example.proyectohospital.modelos.ChatSugerencia;
import com.example.proyectohospital.modelos.ContadorNotificacionesResponse;
import com.example.proyectohospital.modelos.Cita;
import com.example.proyectohospital.modelos.CitaRequest;
import com.example.proyectohospital.modelos.CitaResponse;
import com.example.proyectohospital.modelos.Doctor;
import com.example.proyectohospital.modelos.DoctorResponse;
import com.example.proyectohospital.modelos.EnviarMensajeRequest;
import com.example.proyectohospital.modelos.EnviarMensajeResponse;
import com.example.proyectohospital.modelos.LoginRequest;
import com.example.proyectohospital.modelos.LoginResponse;
import com.example.proyectohospital.modelos.MedicamentoResponse;
import com.example.proyectohospital.modelos.MensajeResponse;
import com.example.proyectohospital.modelos.NotificacionCita;
import com.example.proyectohospital.modelos.NotificacionMedicamento;
import com.example.proyectohospital.modelos.NotificacionResponse;
import com.example.proyectohospital.modelos.UsuarioResponse;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface ApiService {

    // ======================================
    // AUTENTICACIÓN
    // ======================================
    @POST("loginCliente")
    Call<LoginResponse> login(@Body LoginRequest request);

    // ======================================
    // DOCTORES
    // ======================================
    @GET("doctores/top")
    Call<List<Doctor>> getTopDoctores();

    @GET("doctores/lista")
    Call<List<Doctor>> getListaDoctores();

    @GET("GetDoctores/{iddoctor}")
    Call<DoctorResponse> getDoctorById(@Path("iddoctor") int idDoctor);

    // ======================================
    // MEDICAMENTOS Y RECETAS
    // ======================================
    @GET("recetas/{idPaciente}/{fecha}")
    Call<List<MedicamentoResponse>> getMedicamentos(
            @Path("idPaciente") int idPaciente,
            @Path("fecha") String fecha
    );

    // ======================================
    // NOTIFICACIONES - MEDICAMENTOS
    // ======================================
    @GET("notificaciones/historial/{id_paciente}")
    Call<List<NotificacionResponse>> getHistorialNotificaciones(
            @Path("id_paciente") int idPaciente
    );

    @POST("notificaciones/actualizar")
    Call<ActualizarNotificacionResponse> actualizarNotificacion(
            @Body NotificacionMedicamento notificacion
    );

    @POST("notificaciones/marcar-leidas/{id_paciente}")
    Call<MensajeResponse> marcarTodasLeidas(
            @Path("id_paciente") int idPaciente
    );

    @GET("notificaciones/contador/{id_paciente}")
    Call<ContadorNotificacionesResponse> getContadorNotificaciones(
            @Path("id_paciente") int idPaciente
    );

    // ======================================
    // CITAS
    // ======================================

    /**
     * Crear una nueva cita
     */
    @POST("citas/crear")
    Call<CitaResponse> crearCita(@Body CitaRequest citaRequest);

    /**
     * Obtener historial de citas del paciente
     */
    @GET("citas/historial/{id_paciente}")
    Call<List<Cita>> getHistorialCitas(
            @Path("id_paciente") int idPaciente
    );

    /**
     * Obtener citas próximas del paciente
     */
    @GET("citas/proximas/{id_paciente}")
    Call<List<Cita>> getCitasProximas(
            @Path("id_paciente") int idPaciente
    );

    /**
     * Actualizar/reprogramar una cita existente
     */
    @PUT("citas/actualizar/{id_cita}")
    Call<MensajeResponse> actualizarCita(
            @Path("id_cita") int idCita,
            @Body CitaRequest citaRequest
    );

    /**
     * Cancelar una cita
     */
    @DELETE("citas/cancelar/{id_cita}")
    Call<MensajeResponse> cancelarCita(
            @Path("id_cita") int idCita,
            @Query("id_paciente") int idPaciente
    );

    // ======================================
    // NOTIFICACIONES - CITAS
    // ======================================

    /**
     * Obtener notificaciones relacionadas con citas
     */
    @GET("notificaciones/citas/{id_paciente}")
    Call<List<NotificacionCita>> getNotificacionesCitas(
            @Path("id_paciente") int idPaciente
    );

    /**
     * Marcar una notificación de cita como leída
     */
    @POST("notificaciones/citas/marcar-leida/{id_notificacion}")
    Call<MensajeResponse> marcarNotificacionCitaLeida(
            @Path("id_notificacion") int idNotificacion
    );

    // ======================================
    // USUARIO
    // ======================================
    @GET("usuario/{id}")
    Call<UsuarioResponse> obtenerUsuario(
            @Header("Authorization") String token,
            @Path("id") int idUsuario
    );

    @PUT("usuario/{id}")
    Call<UsuarioResponse> actualizarUsuario(
            @Header("Authorization") String token,
            @Path("id") int idUsuario,
            @Body UsuarioResponse usuario
    );

    @GET("chat/conversacion/{id_paciente}")
    Call<ChatAsistenteActivity.ConversacionResponse> getConversacionPaciente(
            @Path("id_paciente") int idPaciente
    );

    /**
     * Obtener mensajes de una conversación
     */
    @GET("chat/mensajes/{id_conversacion}")
    Call<List<ChatMensaje>> getMensajesConversacion(
            @Path("id_conversacion") int idConversacion,
            @Query("limit") int limit
    );

    /**
     * Enviar un mensaje y recibir respuesta automática
     */
    @POST("chat/mensaje")
    Call<EnviarMensajeResponse> enviarMensaje(
            @Body EnviarMensajeRequest request
    );

    /**
     * Obtener sugerencias personalizadas para el paciente
     */
    @GET("chat/sugerencias/{id_paciente}")
    Call<List<ChatSugerencia>> getSugerenciasPersonalizadas(
            @Path("id_paciente") int idPaciente
    );

    /**
     * Eliminar/archivar una conversación
     */
    @DELETE("chat/conversacion/{id_conversacion}")
    Call<MensajeResponse> eliminarConversacion(
            @Path("id_conversacion") int idConversacion
    );
}