package com.example.proyectohospital.modelos;

public class CitaRequest {
    private int idPaciente;
    private int idDoctor;
    private String fechaCita;
    private String horaCita;
    private String motivo;
    private String lugarConsulta;

    public CitaRequest() {}

    public CitaRequest(int idPaciente, int idDoctor, String fechaCita,
                       String horaCita, String motivo, String lugarConsulta) {
        this.idPaciente = idPaciente;
        this.idDoctor = idDoctor;
        this.fechaCita = fechaCita;
        this.horaCita = horaCita;
        this.motivo = motivo;
        this.lugarConsulta = lugarConsulta;
    }

    // Getters y Setters
    public int getIdPaciente() { return idPaciente; }
    public void setIdPaciente(int idPaciente) { this.idPaciente = idPaciente; }

    public int getIdDoctor() { return idDoctor; }
    public void setIdDoctor(int idDoctor) { this.idDoctor = idDoctor; }

    public String getFechaCita() { return fechaCita; }
    public void setFechaCita(String fechaCita) { this.fechaCita = fechaCita; }

    public String getHoraCita() { return horaCita; }
    public void setHoraCita(String horaCita) { this.horaCita = horaCita; }

    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }

    public String getLugarConsulta() { return lugarConsulta; }
    public void setLugarConsulta(String lugarConsulta) { this.lugarConsulta = lugarConsulta; }
}
