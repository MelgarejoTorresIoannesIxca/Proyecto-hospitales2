package com.example.proyectohospital.Configuraciones;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;

import com.example.proyectohospital.R;
import com.example.proyectohospital.Principal.MainPrincipalCliente;
import com.example.proyectohospital.calendario.Activity_Calendario;

public class Perfil extends AppCompatActivity {

    // Menú opciones
    LinearLayout menuPerfil, menuFavoritos, menuConfiguracion, menuSalir;

    // Menú inferior
    LinearLayout btn_home, btn_mensajes, btn_doctores, btn_calendario;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        // ============================
        // Inicializar opciones del menú
        // ============================
        menuPerfil = findViewById(R.id.menuPerfil);
        menuFavoritos = findViewById(R.id.menuFavoritos);
        menuConfiguracion = findViewById(R.id.menuConfiguracion);
        menuSalir = findViewById(R.id.menuSalir);

        // ============================
        // Inicializar menú inferior
        // ============================
        btn_home = findViewById(R.id.btn_home);
        btn_mensajes = findViewById(R.id.btn_mensajes);
        btn_doctores = findViewById(R.id.btn_doctores);
        btn_calendario = findViewById(R.id.btn_calendario);

        // ============================
        // Eventos click opciones menú
        // ============================
        menuPerfil.setOnClickListener(v ->
                startActivity(new Intent(Perfil.this, EditarPerfil.class)));

        menuFavoritos.setOnClickListener(v ->
                startActivity(new Intent(Perfil.this, MainPrincipalCliente.class))); // Cambiar a FavoritosActivity

        menuConfiguracion.setOnClickListener(v ->
                startActivity(new Intent(Perfil.this, Configuracion_2daparte.class))); // Cambiar a ConfiguracionActivity

        menuSalir.setOnClickListener(v -> {
            // Acción cerrar sesión, por ejemplo:
            finishAffinity(); // Cierra todas las activities
        });


        btn_home.setOnClickListener(v ->
                startActivity(new Intent(Perfil.this, MainPrincipalCliente.class)));

        btn_mensajes.setOnClickListener(v ->
                startActivity(new Intent(Perfil.this, MainPrincipalCliente.class))); // Cambiar a MensajesActivity

        btn_doctores.setOnClickListener(v ->
                startActivity(new Intent(Perfil.this, MainPrincipalCliente.class))); // Cambiar a DoctoresActivity

        // Ya estamos en Perfil, no hacemos nada
        btn_calendario.setOnClickListener(v ->
                startActivity(new Intent(Perfil.this, Activity_Calendario.class))); // Cambiar a CalendarioActivity
    }
}
