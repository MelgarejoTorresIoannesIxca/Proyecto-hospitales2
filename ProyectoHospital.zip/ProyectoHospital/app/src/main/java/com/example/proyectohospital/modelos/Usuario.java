package com.example.proyectohospital.modelos;

public class Usuario {
    public String mensaje;
    public int exito;
    public int idUsuarios;

    public Usuario() {
    }

    public Usuario(String mensaje, int exito, int idUsuarios) {
        this.mensaje = mensaje;
        this.exito = exito;
        this.idUsuarios = idUsuarios;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public int getExito() {
        return exito;
    }

    public void setExito(int exito) {
        this.exito = exito;
    }

    public int getIdUsuarios() {
        return idUsuarios;
    }

    public void setIdUsuarios(int idUsuarios) {
        this.idUsuarios = idUsuarios;
    }
}
