package com.example.proyectohospital.modelos;

public class EnviarMensajeResponse {
    private String status;
    private int idConversacion;
    private MensajeInfo mensajeUsuario;
    private MensajeInfo mensajeAsistente;

    public static class MensajeInfo {
        private int idMensaje;
        private String contenido;
        private String tipoSugerencia;
        private Object metadatos;

        // Getters y Setters
        public int getIdMensaje() { return idMensaje; }
        public void setIdMensaje(int idMensaje) { this.idMensaje = idMensaje; }

        public String getContenido() { return contenido; }
        public void setContenido(String contenido) { this.contenido = contenido; }

        public String getTipoSugerencia() { return tipoSugerencia; }
        public void setTipoSugerencia(String tipoSugerencia) { this.tipoSugerencia = tipoSugerencia; }

        public Object getMetadatos() { return metadatos; }
        public void setMetadatos(Object metadatos) { this.metadatos = metadatos; }
    }

    // Getters y Setters
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public int getIdConversacion() { return idConversacion; }
    public void setIdConversacion(int idConversacion) { this.idConversacion = idConversacion; }

    public MensajeInfo getMensajeUsuario() { return mensajeUsuario; }
    public void setMensajeUsuario(MensajeInfo mensajeUsuario) { this.mensajeUsuario = mensajeUsuario; }

    public MensajeInfo getMensajeAsistente() { return mensajeAsistente; }
    public void setMensajeAsistente(MensajeInfo mensajeAsistente) { this.mensajeAsistente = mensajeAsistente; }
}