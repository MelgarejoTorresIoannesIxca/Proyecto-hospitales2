package com.example.proyectohospital.modelos;

import com.google.gson.annotations.SerializedName;

public class Doctor {

    @SerializedName("idUsuarios")
    private int idUsuarios;

    @SerializedName("nombre")
    private String nombre;

    @SerializedName("apellidoP")
    private String apellidoP;

    @SerializedName("apellidoM")
    private String apellidoM;

    @SerializedName("calificacion")
    private double calificacion;

    @SerializedName("cantidadResenas")
    private int cantidadResenas;

    @SerializedName("especialidades")
    private String especialidades;

    @SerializedName("foto")
    private String foto;

    @SerializedName("descripcion")
    private String descripcion;

    // ----------- GETTERS Y SETTERS -------------

    public int getIdUsuarios() {
        return idUsuarios;
    }

    public void setIdUsuarios(int idUsuarios) {
        this.idUsuarios = idUsuarios;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidoP() {
        return apellidoP;
    }

    public void setApellidoP(String apellidoP) {
        this.apellidoP = apellidoP;
    }

    public String getApellidoM() {
        return apellidoM;
    }

    public void setApellidoM(String apellidoM) {
        this.apellidoM = apellidoM;
    }

    public double getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(double calificacion) {
        this.calificacion = calificacion;
    }

    public int getCantidadResenas() {
        return cantidadResenas;
    }

    public void setCantidadResenas(int cantidadResenas) {
        this.cantidadResenas = cantidadResenas;
    }

    public String getEspecialidades() {
        return especialidades;
    }

    public void setEspecialidades(String especialidades) {
        this.especialidades = especialidades;
    }

    public String getFoto() {
        return foto;
    }

    public void setFoto(String foto) {
        this.foto = foto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }



    public String getNombreCompleto() {
        return nombre + " " + apellidoP + " " + apellidoM;
    }
}
