package com.example.proyectohospital.servicios;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;
import com.example.proyectohospital.modelos.NotificacionMedicamento;
import java.util.List;

public class NotificacionActionReceiver extends BroadcastReceiver {

    private static final String TAG = "NotifActionReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        int notificationId = intent.getIntExtra("notification_id", 0);

        Log.d(TAG, "Acción recibida: " + action + " - ID: " + notificationId);

        // Cerrar la notificación
        NotificationManager notificationManager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (notificationManager != null) {
            notificationManager.cancel(notificationId);
        }

        if ("ACTION_TOMADO".equals(action)) {
            // Marcar como tomado
            int idPaciente = intent.getIntExtra("id_paciente", 0);
            String nombreMedicamento = intent.getStringExtra("nombre_medicamento");
            marcarComoTomado(context, notificationId, idPaciente, nombreMedicamento);
            Toast.makeText(context, "✓ " + nombreMedicamento + " marcado como tomado", Toast.LENGTH_SHORT).show();

        } else if ("ACTION_POSPONER".equals(action)) {
            // Posponer por 15 minutos
            String nombreMedicamento = intent.getStringExtra("nombre_medicamento");
            String dosis = intent.getStringExtra("dosis");
            String horaToma = intent.getStringExtra("hora_toma");
            int idPaciente = intent.getIntExtra("id_paciente", 0);

            posponerNotificacion(context, notificationId, nombreMedicamento, dosis, horaToma, idPaciente);
            Toast.makeText(context, "⏰ Recordatorio pospuesto 15 minutos", Toast.LENGTH_SHORT).show();
        }
    }

    private void marcarComoTomado(Context context, int notificationId, int idPaciente, String nombreMedicamento) {
        com.example.proyectohospital.servicios.NotificacionManager notifManager =
                new com.example.proyectohospital.servicios.NotificacionManager(context);

        // Buscar la notificación correspondiente y marcarla como tomada
        List<NotificacionMedicamento> notificaciones = notifManager.getTodasNotificaciones(idPaciente);
        for (NotificacionMedicamento notif : notificaciones) {
            if (notif.getId() == notificationId) {
                notif.setTomado(true);
                notif.setLeida(true);
                notifManager.actualizarNotificacion(notif);
                Log.d(TAG, "Notificación marcada como tomada: " + nombreMedicamento);
                break;
            }
        }
    }

    private void posponerNotificacion(Context context, int notificationId,
                                      String nombreMedicamento, String dosis,
                                      String horaToma, int idPaciente) {
        // Reprogramar alarma para dentro de 15 minutos
        AlarmScheduler.reprogramarAlarma(context, nombreMedicamento, dosis, horaToma, 15, idPaciente);

        // Marcar la notificación actual como leída pero no tomada
        com.example.proyectohospital.servicios.NotificacionManager notifManager =
                new com.example.proyectohospital.servicios.NotificacionManager(context);

        List<NotificacionMedicamento> notificaciones = notifManager.getTodasNotificaciones(idPaciente);
        for (NotificacionMedicamento notif : notificaciones) {
            if (notif.getId() == notificationId) {
                notif.setLeida(true);
                notifManager.actualizarNotificacion(notif);
                Log.d(TAG, "Notificación pospuesta: " + nombreMedicamento);
                break;
            }
        }
    }
}