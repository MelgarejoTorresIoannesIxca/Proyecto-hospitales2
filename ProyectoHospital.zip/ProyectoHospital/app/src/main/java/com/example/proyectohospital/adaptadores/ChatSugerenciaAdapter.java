package com.example.proyectohospital.adaptadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectohospital.R;
import com.example.proyectohospital.modelos.ChatSugerencia;

import java.util.ArrayList;
import java.util.List;

public class ChatSugerenciaAdapter extends RecyclerView.Adapter<ChatSugerenciaAdapter.ViewHolder> {

    private List<ChatSugerencia> sugerencias;
    private OnSugerenciaClickListener listener;

    public interface OnSugerenciaClickListener {
        void onSugerenciaClick(ChatSugerencia sugerencia);
    }

    public ChatSugerenciaAdapter(OnSugerenciaClickListener listener) {
        this.sugerencias = new ArrayList<>();
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_sugerencia, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ChatSugerencia sugerencia = sugerencias.get(position);
        holder.bind(sugerencia, listener);
    }

    @Override
    public int getItemCount() {
        return sugerencias.size();
    }

    public void setSugerencias(List<ChatSugerencia> sugerencias) {
        this.sugerencias = sugerencias;
        notifyDataSetChanged();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvIcono, tvTitulo, tvDescripcion;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvIcono = itemView.findViewById(R.id.tv_icono_sugerencia);
            tvTitulo = itemView.findViewById(R.id.tv_titulo_sugerencia);
            tvDescripcion = itemView.findViewById(R.id.tv_descripcion_sugerencia);
        }

        public void bind(ChatSugerencia sugerencia, OnSugerenciaClickListener listener) {
            tvIcono.setText(sugerencia.getIcono());
            tvTitulo.setText(sugerencia.getTitulo());
            tvDescripcion.setText(sugerencia.getDescripcion());

            itemView.setOnClickListener(v -> listener.onSugerenciaClick(sugerencia));
        }
    }
}