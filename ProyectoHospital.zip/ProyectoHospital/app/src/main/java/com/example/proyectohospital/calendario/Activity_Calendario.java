package com.example.proyectohospital.calendario;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.proyectohospital.Configuraciones.Perfil;
import com.example.proyectohospital.Principal.activity_notificaciones;
import com.example.proyectohospital.R;
import com.example.proyectohospital.servicios.AlarmReceiver;
import com.example.proyectohospital.Principal.MainPrincipalCliente;

public class Activity_Calendario extends AppCompatActivity {

    private static final String TAG = "Activity_Calendario";
    private static final String PREF_NAME = "SesionUsuario";
    private static final String KEY_ID_USUARIO = "idUsuarios";

    // Barra inferior
    LinearLayout btn_home, btn_mensajes, btn_doctores, btn_calendario;

    // Header
    LinearLayout tab_doctores;
    ImageView btn_notifications, btn_settings;

    private int idPaciente;
    private String fecha = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendario);

        // ==== HEADER ====
        btn_notifications = findViewById(R.id.btn_notifications);
        btn_settings = findViewById(R.id.btn_settings);


        // ==== BOTTOM NAV ====
        btn_home = findViewById(R.id.btn_home);
        btn_mensajes = findViewById(R.id.btn_mensajes);
        btn_doctores = findViewById(R.id.btn_doctores);
        btn_calendario = findViewById(R.id.btn_calendario);

        // Obtener ID del paciente
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        idPaciente = sharedPreferences.getInt(KEY_ID_USUARIO, 0);
        Log.d(TAG, "ID Paciente obtenido: " + idPaciente);

        cargarFragmentos();

        // ==== BOTTOM NAV CLICKS ====
        btn_home.setOnClickListener(v ->
                startActivity(new Intent(this, MainPrincipalCliente.class)));

        btn_mensajes.setOnClickListener(v ->
                startActivity(new Intent(this, activity_notificaciones.class)));

        btn_doctores.setOnClickListener(v ->
                startActivity(new Intent(this, MainPrincipalCliente.class)));

        btn_calendario.setOnClickListener(v -> {
            Log.i(TAG, "Calendario clickeado (ya estás aquí)");
        });

        // ==== HEADER CLICKS (copiados del MainPrincipalCliente) ====

        // Favoritos normal




        // Abrir perfil
        btn_settings.setOnClickListener(v -> abrirMiPerfil());

        // Abrir notificaciones
        btn_notifications.setOnClickListener(v -> {
            Intent intent = new Intent(this, activity_notificaciones.class);
            startActivity(intent);
        });
    }

    // =====================================================
    // CARGAR FRAGMENTO
    // =====================================================
    private void cargarFragmentos() {

        MedicamentosFragment medicamentosFragment = MedicamentosFragment.newInstance(fecha);
        calendario calendarFragment = new calendario();

        calendarFragment.setOnDateSelectedListener(fechaSeleccionada -> {
            medicamentosFragment.actualizarMedicamentos(fechaSeleccionada);
        });

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.fragmentContainerMedicamentos, medicamentosFragment);
        ft.replace(R.id.fragmentContainerCalendar, calendarFragment);
        ft.commit();
    }

    // =====================================================
    // ABRIR MI PERFIL (misma función que el MainPrincipalCliente)
    // =====================================================
    private void abrirMiPerfil() {
        Intent intent = new Intent(Activity_Calendario.this, Perfil.class);
        startActivity(intent);
        Log.i(TAG, "Navegando a Mi Perfil");
    }

    // =====================================================
    // DISPARAR NOTIFICACIÓN DE PRUEBA (idéntico al MainPrincipalCliente)
    // =====================================================
    private void dispararNotificacionDePrueba() {

        if (idPaciente == 0) {
            Toast.makeText(this, "⚠️ Error: ID de paciente no encontrado", Toast.LENGTH_LONG).show();
            Log.e(TAG, "No se puede disparar notificación: idPaciente = 0");
            return;
        }

        Log.d(TAG, "Disparando notificación de prueba desde Calendario. ID Paciente: " + idPaciente);

        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("nombre_medicamento", "Paracetamol TEST");
        intent.putExtra("dosis", "500mg - PRUEBA");
        intent.putExtra("hora_toma", "AHORA");
        intent.putExtra("id_paciente", idPaciente);
        intent.putExtra("notification_id", 11111);

        AlarmReceiver receiver = new AlarmReceiver();
        receiver.onReceive(this, intent);

        Toast.makeText(this, "🔔 Notificación de prueba enviada", Toast.LENGTH_LONG).show();
    }
}
