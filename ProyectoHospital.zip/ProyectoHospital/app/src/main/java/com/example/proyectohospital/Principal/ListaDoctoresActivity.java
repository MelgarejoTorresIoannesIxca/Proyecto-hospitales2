package com.example.proyectohospital.Principal;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectohospital.Configuraciones.Perfil;
import com.example.proyectohospital.R;
import com.example.proyectohospital.adaptadores.DoctorAdapter;
import com.example.proyectohospital.calendario.Activity_Calendario;
import com.example.proyectohospital.modelos.Doctor;
import com.example.proyectohospital.navegacion.ApiService;
import com.example.proyectohospital.navegacion.RetrofitClient;
import com.example.proyectohospital.servicios.AlarmReceiver;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ListaDoctoresActivity extends AppCompatActivity {

    private static final String TAG = "ListaDoctoresActivity";
    private static final String PREF_NAME = "SesionUsuario";
    private static final String KEY_ID_USUARIO = "idUsuarios";

    private ImageView btnSettings, btnNotificaciones;

    private LinearLayout btnHome, btnMensajes, btnDoctores, btnCalendario;

    private RecyclerView rvDoctores;
    private DoctorAdapter adapter;

    private int idPaciente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_doctores);

        // Obteniendo ID del paciente guardado
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        idPaciente = sharedPreferences.getInt(KEY_ID_USUARIO, 0);
        Log.d(TAG, "ID Paciente obtenido: " + idPaciente);

        // HEADER
        btnSettings = findViewById(R.id.btn_settings);
        btnNotificaciones = findViewById(R.id.btn_notifications);

        // BOTTOM NAVIGATION
        btnHome = findViewById(R.id.btn_home);
        btnMensajes = findViewById(R.id.btn_mensajes);
        btnDoctores = findViewById(R.id.btn_doctores);
        btnCalendario = findViewById(R.id.btn_calendario);

        // RECYCLER VIEW
        rvDoctores = findViewById(R.id.rvDoctores);
        rvDoctores.setLayoutManager(new LinearLayoutManager(this));
        adapter = new DoctorAdapter(this);
        rvDoctores.setAdapter(adapter);

        cargarDoctores();
        configurarClicks();
    }

    // -------------------------------------------------
    // CARGAR LISTA DE DOCTORES DESDE API
    // -------------------------------------------------
    private void cargarDoctores() {
        ApiService api = RetrofitClient.getClient().create(ApiService.class);

        Call<List<Doctor>> call = api.getListaDoctores();

        Log.d(TAG, "Realizando petición API /doctores/lista ...");

        call.enqueue(new Callback<List<Doctor>>() {
            @Override
            public void onResponse(Call<List<Doctor>> call, Response<List<Doctor>> response) {

                if (response.isSuccessful() && response.body() != null) {

                    List<Doctor> doctores = response.body();

                    Log.d(TAG, "Doctores recibidos: " + doctores.size());
                    adapter.setDoctores(doctores);

                } else {
                    Log.e(TAG, "Error API: respuesta no exitosa");
                    Toast.makeText(ListaDoctoresActivity.this,
                            "❌ Error al cargar doctores",
                            Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<List<Doctor>> call, Throwable t) {
                Log.e(TAG, "Fallo conexión API: " + t.getMessage());
                Toast.makeText(ListaDoctoresActivity.this,
                        "❌ Error de conexión\n" + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    // -------------------------------------------------
    // ACCIONES DEL HEADER Y NAVEGACIÓN
    // -------------------------------------------------
    private void configurarClicks() {

        // Configuración → Perfil
        btnSettings.setOnClickListener(v -> {
            Intent intent = new Intent(this, Perfil.class);
            startActivity(intent);
        });

        // Notificaciones
        btnNotificaciones.setOnClickListener(v -> {
            Intent intent = new Intent(this, activity_notificaciones.class);
            startActivity(intent);
        });

        // HOME
        btnHome.setOnClickListener(v -> {
            startActivity(new Intent(this, MainPrincipalCliente.class));
        });

        // MENSAJES
        btnMensajes.setOnClickListener(v ->
                Toast.makeText(this, "Mensajes aún no implementado", Toast.LENGTH_SHORT).show()
        );

        // DOCTORES (ya estás aquí)
        btnDoctores.setOnClickListener(v ->
                Toast.makeText(this, "Ya estás en Doctores", Toast.LENGTH_SHORT).show()
        );

        // CALENDARIO
        btnCalendario.setOnClickListener(v -> {
            startActivity(new Intent(this, Activity_Calendario.class));
        });
    }

    // Notificación de prueba
    private void dispararNotificacionDePrueba() {
        if (idPaciente == 0) {
            Toast.makeText(this, "⚠️ Error: ID de paciente no encontrado", Toast.LENGTH_LONG).show();
            return;
        }

        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("nombre_medicamento", "Prueba Doctor Activity");
        intent.putExtra("dosis", "500mg TEST");
        intent.putExtra("hora_toma", "AHORA");
        intent.putExtra("id_paciente", idPaciente);
        intent.putExtra("notification_id", 22222);

        AlarmReceiver receiver = new AlarmReceiver();
        receiver.onReceive(this, intent);

        Toast.makeText(this, "🔔 Notificación de prueba enviada", Toast.LENGTH_LONG).show();
    }
}
