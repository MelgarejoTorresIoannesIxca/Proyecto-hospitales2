package com.example.proyectohospital.calendario;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CalendarView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.proyectohospital.R;

public class calendario extends Fragment {

    private OnDateSelectedListener listener;

    public interface OnDateSelectedListener {
        void onDateSelected(String fecha);
    }

    public calendario() {
        // Constructor vacío obligatorio
    }

    public static calendario newInstance() {
        return new calendario();
    }

    public void setOnDateSelectedListener(OnDateSelectedListener listener) {
        this.listener = listener;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_calendario, container, false);

        CalendarView calendarView = view.findViewById(R.id.calendarView);

        calendarView.setOnDateChangeListener((view1, year, month, dayOfMonth) -> {
            String fecha = String.format("%04d-%02d-%02d",
                    year, month + 1, dayOfMonth);

            if (listener != null) {
                listener.onDateSelected(fecha);
            }
        });

        return view;
    }
}
