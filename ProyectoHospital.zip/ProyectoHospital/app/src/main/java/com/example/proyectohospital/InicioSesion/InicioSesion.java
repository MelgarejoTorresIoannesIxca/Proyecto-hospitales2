package com.example.proyectohospital.InicioSesion;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.proyectohospital.Principal.MainPrincipalCliente;
import com.example.proyectohospital.R;
import com.example.proyectohospital.modelos.LoginRequest;
import com.example.proyectohospital.modelos.LoginResponse;
import com.example.proyectohospital.navegacion.ApiService;
import com.example.proyectohospital.navegacion.RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InicioSesion extends AppCompatActivity {

    private EditText BCorreoElectronico, BPassword;
    private LinearLayout BLogin;

    private SharedPreferences sharedPreferences;

    private static final String PREF_NAME = "SesionUsuario";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_TOKEN = "token";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inicio_sesion);

        BCorreoElectronico = findViewById(R.id.BCorreoElectronico);
        BPassword = findViewById(R.id.BPassword);
        BLogin = findViewById(R.id.BLogin);

        // 👉 Nuevo: botón de registro
        TextView tvRegistrarse = findViewById(R.id.tvRegistrarse);

        // 👉 Click para ir a la pantalla de registro
        tvRegistrarse.setOnClickListener(v -> {
            Intent intent = new Intent(InicioSesion.this, Registrarse.class);
            startActivity(intent);
        });

        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        int idPaciente = sharedPreferences.getInt("idUsuarios", 0);

        String tokenGuardado = sharedPreferences.getString(KEY_TOKEN, null);
        if (tokenGuardado != null) {
            startActivity(new Intent(this, MainPrincipalCliente.class));
            finish();
            return;
        }

        BLogin.setOnClickListener(v -> iniciarSesion());
    }

    private void iniciarSesion() {
        String email = BCorreoElectronico.getText().toString().trim();
        String password = BPassword.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        ApiService api = RetrofitClient.getClient().create(ApiService.class);
        LoginRequest request = new LoginRequest(email, password);

        api.login(request).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {

                if (!response.isSuccessful() || response.body() == null) {
                    Toast.makeText(getApplicationContext(),
                            "Error al recibir respuesta del servidor",
                            Toast.LENGTH_SHORT).show();
                    return;
                }

                LoginResponse res = response.body();

                if (res.usuario != null && res.usuario.exito == 1) {

                    SharedPreferences.Editor editor = sharedPreferences.edit();
                    editor.putString(KEY_EMAIL, email);
                    editor.putString(KEY_PASSWORD, password);
                    editor.putString(KEY_TOKEN, "TOKEN_LOCAL");
                    editor.putInt("idUsuarios", res.usuario.idUsuarios);
                    editor.apply();

                    Toast.makeText(getApplicationContext(),
                            res.usuario.mensaje,
                            Toast.LENGTH_SHORT).show();

                    irPantallaPrincipal();
                } else {
                    String mensajeError = (res.usuario != null && res.usuario.mensaje != null)
                            ? res.usuario.mensaje
                            : "Usuario o contraseña incorrectos";
                    Toast.makeText(getApplicationContext(), mensajeError, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Toast.makeText(getApplicationContext(),
                        "No se pudo conectar con el servidor: " + t.getMessage(),
                        Toast.LENGTH_LONG).show();
            }
        });
    }

    private void irPantallaPrincipal() {
        Intent intent = new Intent(this, MainPrincipalCliente.class);
        startActivity(intent);
        finish();
    }
}
