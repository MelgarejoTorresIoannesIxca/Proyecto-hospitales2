package com.example.proyectohospital.modelos;

public class CitaResponse {
    private String status;
    private String mensaje;
    private int idCita;

    public CitaResponse() {}

    public CitaResponse(String status, String mensaje, int idCita) {
        this.status = status;
        this.mensaje = mensaje;
        this.idCita = idCita;
    }

    // Getters y Setters
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getMensaje() { return mensaje; }
    public void setMensaje(String mensaje) { this.mensaje = mensaje; }

    public int getIdCita() { return idCita; }
    public void setIdCita(int idCita) { this.idCita = idCita; }
}