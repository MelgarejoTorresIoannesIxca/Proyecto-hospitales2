package com.example.proyectohospital.navegacion;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;

import java.lang.reflect.Type;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;

public class RetrofitClient {
    private static final String BASE_URL = "http://192.168.56.1:8000/";
    private static Retrofit retrofit = null;

    public static Retrofit getClient() {
        if (retrofit == null) {
            // ========== INTERCEPTOR PARA LOGS ==========
            HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
            interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);

            OkHttpClient client = new OkHttpClient.Builder()
                    .addInterceptor(interceptor)
                    .build();

            // ========== DESERIALIZADOR PERSONALIZADO PARA STRING ==========
            // Convierte tiempos en formato ISO 8601 (PT14H30M) a HH:MM
            JsonDeserializer<String> stringDeserializer = new JsonDeserializer<String>() {
                @Override
                public String deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
                    String value = json.getAsString();

                    // Si viene en formato ISO 8601 de Time (PT14H30M), convertir a HH:MM
                    if (value != null && value.startsWith("PT")) {
                        return convertirTiempoISO(value);
                    }

                    return value;
                }
            };

            // ========== DESERIALIZADOR PERSONALIZADO PARA BOOLEAN ==========
            // Convierte números (0, 1) a booleanos (false, true)
            JsonDeserializer<Boolean> booleanDeserializer = new JsonDeserializer<Boolean>() {
                @Override
                public Boolean deserialize(JsonElement json, Type typeOfT, JsonDeserializationContext context) throws JsonParseException {
                    if (json.isJsonPrimitive()) {
                        if (json.getAsJsonPrimitive().isNumber()) {
                            // Convertir número a booleano: 0 = false, cualquier otro = true
                            return json.getAsInt() != 0;
                        } else if (json.getAsJsonPrimitive().isBoolean()) {
                            return json.getAsBoolean();
                        }
                    }
                    return false;
                }
            };

            // ========== CREAR GSON CON DESERIALIZADORES PERSONALIZADOS ==========
            Gson gson = new GsonBuilder()
                    .registerTypeAdapter(String.class, stringDeserializer)
                    .registerTypeAdapter(Boolean.class, booleanDeserializer)
                    .registerTypeAdapter(boolean.class, booleanDeserializer)
                    .create();

            // ========== CONSTRUIR RETROFIT ==========
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .client(client)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }

        return retrofit;
    }

    /**
     * Convierte formato ISO 8601 de Time (PT14H30M) a formato legible (14:30)
     *
     * Ejemplos de conversión:
     * - PT11H → 11:00
     * - PT14H30M → 14:30
     * - PT9H → 09:00
     * - PT0H → 00:00
     */
    private static String convertirTiempoISO(String tiempo) {
        try {
            // Remover "PT" al inicio
            String time = tiempo.substring(2);

            int horas = 0;
            int minutos = 0;

            // Extraer horas si contiene "H"
            if (time.contains("H")) {
                int hIndex = time.indexOf("H");
                String horasStr = time.substring(0, hIndex);
                horas = Integer.parseInt(horasStr);
                time = time.substring(hIndex + 1);
            }

            // Extraer minutos si contiene "M"
            if (time.contains("M")) {
                int mIndex = time.indexOf("M");
                String minutosStr = time.substring(0, mIndex);
                if (!minutosStr.isEmpty()) {
                    minutos = Integer.parseInt(minutosStr);
                }
            }

            // Retornar en formato HH:MM con ceros a la izquierda
            return String.format("%02d:%02d", horas, minutos);

        } catch (Exception e) {
            // Si hay error en parsing, retornar el valor original
            return tiempo;
        }
    }
}