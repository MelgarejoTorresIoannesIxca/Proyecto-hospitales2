package com.example.proyectohospital.modelos;

public class ChatConversacion {
    private int idConversacion;
    private int idPaciente;
    private String fechaCreacion;
    private String ultimaActualizacion;
    private String estado;

    public ChatConversacion() {}

    // Getters y Setters
    public int getIdConversacion() { return idConversacion; }
    public void setIdConversacion(int idConversacion) { this.idConversacion = idConversacion; }

    public int getIdPaciente() { return idPaciente; }
    public void setIdPaciente(int idPaciente) { this.idPaciente = idPaciente; }

    public String getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(String fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public String getUltimaActualizacion() { return ultimaActualizacion; }
    public void setUltimaActualizacion(String ultimaActualizacion) {
        this.ultimaActualizacion = ultimaActualizacion;
    }

    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}