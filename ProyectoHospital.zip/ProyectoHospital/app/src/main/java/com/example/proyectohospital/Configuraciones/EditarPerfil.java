package com.example.proyectohospital.Configuraciones;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.proyectohospital.R;
import com.example.proyectohospital.modelos.UsuarioResponse;
import com.example.proyectohospital.navegacion.ApiService;
import com.example.proyectohospital.navegacion.RetrofitClient;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditarPerfil extends AppCompatActivity {

    private EditText etNombre, etTelefono, etCorreo;
    private Button btnActualizar;

    private SharedPreferences sharedPreferences;
    private static final String PREF_NAME = "SesionUsuario";
    private static final String KEY_TOKEN = "token";
    private static final String KEY_ID = "idUsuarios";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_perfil);

        // Referencias a los EditText y Button
        etNombre = findViewById(R.id.etNombre);
        etTelefono = findViewById(R.id.etTelefono);
        etCorreo = findViewById(R.id.etCorreo);
        btnActualizar = findViewById(R.id.btnActualizar);

        sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);

        // Recuperamos los datos del usuario usando el token
        String token = sharedPreferences.getString(KEY_TOKEN, null);
        int idUsuario = sharedPreferences.getInt(KEY_ID, -1);
        if (token != null && idUsuario != -1) {
            cargarDatosUsuario(token, idUsuario);
        } else {
            Toast.makeText(this, "No se encontró sesión activa", Toast.LENGTH_SHORT).show();
        }

        btnActualizar.setOnClickListener(v -> actualizarUsuario(token, idUsuario));
    }

    private void cargarDatosUsuario(String token, int idUsuario) {
        ApiService api = RetrofitClient.getClient().create(ApiService.class);
        api.obtenerUsuario("Bearer " + token, idUsuario).enqueue(new Callback<UsuarioResponse>() {
            @Override
            public void onResponse(Call<UsuarioResponse> call, Response<UsuarioResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    UsuarioResponse usuario = response.body();
                    etNombre.setText(usuario.nombre);
                    etTelefono.setText(String.valueOf(usuario.telefono));
                    etCorreo.setText(usuario.CorreoElectronico);
                } else {
                    Toast.makeText(getApplicationContext(), "Error al cargar datos", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UsuarioResponse> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "No se pudo conectar: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void actualizarUsuario(String token, int idUsuario) {
        String nombre = etNombre.getText().toString().trim();
        String telefono = etTelefono.getText().toString().trim();
        String correo = etCorreo.getText().toString().trim();

        if(nombre.isEmpty() || telefono.isEmpty() || correo.isEmpty()){
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        ApiService api = RetrofitClient.getClient().create(ApiService.class);
        UsuarioResponse usuarioActualizar = new UsuarioResponse();
        usuarioActualizar.nombre = nombre;
        usuarioActualizar.telefono = Integer.parseInt(telefono);
        usuarioActualizar.CorreoElectronico = correo;

        api.actualizarUsuario("Bearer " + token, idUsuario, usuarioActualizar).enqueue(new Callback<UsuarioResponse>() {
            @Override
            public void onResponse(Call<UsuarioResponse> call, Response<UsuarioResponse> response) {
                if(response.isSuccessful()){
                    Toast.makeText(getApplicationContext(), "Datos actualizados", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getApplicationContext(), "Error al actualizar", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UsuarioResponse> call, Throwable t) {
                Toast.makeText(getApplicationContext(), "No se pudo conectar: " + t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
