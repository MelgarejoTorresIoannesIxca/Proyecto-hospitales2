package com.example.proyectohospital.modelos;

public class MedicamentoResponse {
    private String nombre;
    private String dosis;
    private String horas_toma;  // Nueva línea

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDosis() {
        return dosis;
    }

    public void setDosis(String dosis) {
        this.dosis = dosis;
    }

    public String getHorasToma() {
        return horas_toma;
    }

    public void setHorasToma(String horas_toma) {
        this.horas_toma = horas_toma;
    }
}