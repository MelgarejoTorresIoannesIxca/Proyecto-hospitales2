package com.example.proyectohospital.modelos;

public class ChatSugerencia {
    private int idSugerencia;
    private String titulo;
    private String descripcion;
    private String tipo;
    private String accion;
    private String icono;
    private int prioridad;

    public ChatSugerencia() {}

    // Getters y Setters
    public int getIdSugerencia() { return idSugerencia; }
    public void setIdSugerencia(int idSugerencia) { this.idSugerencia = idSugerencia; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getAccion() { return accion; }
    public void setAccion(String accion) { this.accion = accion; }

    public String getIcono() { return icono; }
    public void setIcono(String icono) { this.icono = icono; }

    public int getPrioridad() { return prioridad; }
    public void setPrioridad(int prioridad) { this.prioridad = prioridad; }
}
