package com.example.proyectohospital.adaptadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectohospital.R;
import com.example.proyectohospital.modelos.ChatMensaje;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class ChatMensajeAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private static final int VIEW_TYPE_USUARIO = 1;
    private static final int VIEW_TYPE_ASISTENTE = 2;

    private List<ChatMensaje> mensajes;
    private OnMensajeListener listener;

    public interface OnMensajeListener {
        void onAccionRapida(ChatMensaje mensaje, String accion);
    }

    public ChatMensajeAdapter(OnMensajeListener listener) {
        this.mensajes = new ArrayList<>();
        this.listener = listener;
    }

    @Override
    public int getItemViewType(int position) {
        ChatMensaje mensaje = mensajes.get(position);
        return mensaje.esDelUsuario() ? VIEW_TYPE_USUARIO : VIEW_TYPE_ASISTENTE;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_USUARIO) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_mensaje_usuario, parent, false);
            return new UsuarioViewHolder(view);
        } else {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_mensaje_asistente, parent, false);
            return new AsistenteViewHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ChatMensaje mensaje = mensajes.get(position);

        if (holder instanceof UsuarioViewHolder) {
            ((UsuarioViewHolder) holder).bind(mensaje);
        } else if (holder instanceof AsistenteViewHolder) {
            ((AsistenteViewHolder) holder).bind(mensaje, listener);
        }
    }

    @Override
    public int getItemCount() {
        return mensajes.size();
    }

    public void setMensajes(List<ChatMensaje> mensajes) {
        this.mensajes = mensajes;
        notifyDataSetChanged();
    }

    public void agregarMensaje(ChatMensaje mensaje) {
        this.mensajes.add(mensaje);
        notifyItemInserted(mensajes.size() - 1);
    }

    public void limpiarMensajes() {
        this.mensajes.clear();
        notifyDataSetChanged();
    }

    // ========== ViewHolder Usuario ==========
    static class UsuarioViewHolder extends RecyclerView.ViewHolder {
        TextView tvMensaje, tvHora;

        public UsuarioViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMensaje = itemView.findViewById(R.id.tv_mensaje_usuario);
            tvHora = itemView.findViewById(R.id.tv_hora_usuario);
        }

        public void bind(ChatMensaje mensaje) {
            tvMensaje.setText(mensaje.getContenido());
            tvHora.setText(formatearHora(mensaje.getFechaEnvio()));
        }
    }
    static class AsistenteViewHolder extends RecyclerView.ViewHolder {
        TextView tvMensaje, tvHora;
        LinearLayout containerAcciones;
        Button btnAccion1, btnAccion2;

        public AsistenteViewHolder(@NonNull View itemView) {
            super(itemView);
            tvMensaje = itemView.findViewById(R.id.tv_mensaje_asistente);
            tvHora = itemView.findViewById(R.id.tv_hora_asistente);
            containerAcciones = itemView.findViewById(R.id.container_acciones_rapidas);
            btnAccion1 = itemView.findViewById(R.id.btn_accion_1);
            btnAccion2 = itemView.findViewById(R.id.btn_accion_2);
        }

        public void bind(ChatMensaje mensaje, OnMensajeListener listener) {
            tvMensaje.setText(mensaje.getContenido());
            tvHora.setText(formatearHora(mensaje.getFechaEnvio()));

            // Mostrar botones de acción si es un tipo específico
            if ("medicamento".equals(mensaje.getTipoSugerencia())) {
                containerAcciones.setVisibility(View.VISIBLE);
                btnAccion1.setText("Ver medicamentos");
                btnAccion2.setText("Recordatorios");

                btnAccion1.setOnClickListener(v ->
                        listener.onAccionRapida(mensaje, "ver_medicamentos"));
                btnAccion2.setOnClickListener(v ->
                        listener.onAccionRapida(mensaje, "configurar_recordatorios"));

            } else if ("cita".equals(mensaje.getTipoSugerencia())) {
                containerAcciones.setVisibility(View.VISIBLE);
                btnAccion1.setText("Ver citas");
                btnAccion2.setText("Agendar");

                btnAccion1.setOnClickListener(v ->
                        listener.onAccionRapida(mensaje, "ver_citas"));
                btnAccion2.setOnClickListener(v ->
                        listener.onAccionRapida(mensaje, "agendar_cita"));

            } else {
                containerAcciones.setVisibility(View.GONE);
            }
        }
    }

    // Método auxiliar para formatear hora
    private static String formatearHora(String fechaEnvio) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            SimpleDateFormat outputFormat = new SimpleDateFormat("HH:mm", Locale.getDefault());
            Date date = inputFormat.parse(fechaEnvio);
            return outputFormat.format(date);
        } catch (Exception e) {
            return "";
        }
    }
}

