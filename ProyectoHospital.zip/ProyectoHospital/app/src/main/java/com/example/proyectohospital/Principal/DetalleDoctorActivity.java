package com.example.proyectohospital.Principal;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import com.example.proyectohospital.Principal.Detalle_Doctores;
import com.example.proyectohospital.R;
import com.squareup.picasso.Picasso;

public class DetalleDoctorActivity extends AppCompatActivity {

    ImageView imgDoctor;
    TextView tvNombre, tvEspecialidad, tvRating, tvDistance, tvInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle_doctores);

        imgDoctor = findViewById(R.id.imgDoctor);
        tvNombre = findViewById(R.id.tvDoctorName);
        tvEspecialidad = findViewById(R.id.tvSpecialty);
        tvRating = findViewById(R.id.tvRating);
        tvDistance = findViewById(R.id.tvDistance);
        tvInfo = findViewById(R.id.tvDoctorInfo);

        // ********************
        // RECIBIR LOS DATOS
        // ********************
        String nombre = getIntent().getStringExtra("nombre");
        String especialidad = getIntent().getStringExtra("especialidad");
        String foto = getIntent().getStringExtra("foto");
        String rating = getIntent().getStringExtra("rating");
        String distancia = getIntent().getStringExtra("distancia");
        String info = getIntent().getStringExtra("info");

        // Asignar datos en pantalla
        tvNombre.setText(nombre);
        tvEspecialidad.setText(especialidad);
        tvRating.setText("⭐ " + rating);
        tvDistance.setText("📍 " + distancia);
        tvInfo.setText(info);

        // Si usas URL del backend usa Picasso
        if (foto != null && !foto.isEmpty()) {
            Picasso.get()
                    .load(foto)
                    .placeholder(R.drawable.doctor_detalle) // imagen por defecto
                    .into(imgDoctor);
        }
    }
}
