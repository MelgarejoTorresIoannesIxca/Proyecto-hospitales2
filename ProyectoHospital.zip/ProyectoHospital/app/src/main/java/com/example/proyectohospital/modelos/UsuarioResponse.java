package com.example.proyectohospital.modelos;

public class UsuarioResponse {
    public int idUsuarios;
    public String nombre;
    public String apellidoP;
    public String apellidoM;
    public String ciudad;
    public int telefono;
    public String CorreoElectronico;
    public String sexo;
    public String foto;
    public String TipoUsuario;
    public String password;
    public String descripcion;

    // Getters y Setters
    public int getIdUsuarios() { return idUsuarios; }
    public void setIdUsuarios(int idUsuarios) { this.idUsuarios = idUsuarios; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getApellidoP() { return apellidoP; }
    public void setApellidoP(String apellidoP) { this.apellidoP = apellidoP; }

    public String getApellidoM() { return apellidoM; }
    public void setApellidoM(String apellidoM) { this.apellidoM = apellidoM; }

    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }

    public int getTelefono() { return telefono; }
    public void setTelefono(int telefono) { this.telefono = telefono; }

    public String getCorreoElectronico() { return CorreoElectronico; }
    public void setCorreoElectronico(String correoElectronico) { this.CorreoElectronico = correoElectronico; }

    public String getSexo() { return sexo; }
    public void setSexo(String sexo) { this.sexo = sexo; }

    public String getFoto() { return foto; }
    public void setFoto(String foto) { this.foto = foto; }

    public String getTipoUsuario() { return TipoUsuario; }
    public void setTipoUsuario(String tipoUsuario) { this.TipoUsuario = tipoUsuario; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }
}
