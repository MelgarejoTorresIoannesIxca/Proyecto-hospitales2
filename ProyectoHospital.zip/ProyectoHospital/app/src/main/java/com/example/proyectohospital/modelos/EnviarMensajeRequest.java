package com.example.proyectohospital.modelos;

public class EnviarMensajeRequest {
    private int idPaciente;
    private String contenido;
    private String tipo;

    public EnviarMensajeRequest(int idPaciente, String contenido) {
        this.idPaciente = idPaciente;
        this.contenido = contenido;
        this.tipo = "usuario";
    }

    // Getters y Setters
    public int getIdPaciente() { return idPaciente; }
    public void setIdPaciente(int idPaciente) { this.idPaciente = idPaciente; }

    public String getContenido() { return contenido; }
    public void setContenido(String contenido) { this.contenido = contenido; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }
}

