package com.example.proyectohospital.adaptadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectohospital.R;
import com.example.proyectohospital.modelos.MedicamentoResponse;

import java.util.List;

public class MedicamentoAdapter extends RecyclerView.Adapter<MedicamentoAdapter.MedicamentoViewHolder> {

    private List<MedicamentoResponse> medicamentos;

    public MedicamentoAdapter(List<MedicamentoResponse> medicamentos) {
        this.medicamentos = medicamentos;
    }

    public void setMedicamentos(List<MedicamentoResponse> medicamentos) {
        this.medicamentos = medicamentos;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MedicamentoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_medicamento, parent, false);
        return new MedicamentoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MedicamentoViewHolder holder, int position) {
        MedicamentoResponse med = medicamentos.get(position);
        holder.tvNombre.setText(med.getNombre());
        holder.tvDosis.setText(med.getDosis());
    }

    @Override
    public int getItemCount() {
        return medicamentos.size();
    }

    static class MedicamentoViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre, tvDosis;

        public MedicamentoViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvMedicamentoNombre);
            tvDosis = itemView.findViewById(R.id.tvMedicamentoDosis);
        }
    }
}
