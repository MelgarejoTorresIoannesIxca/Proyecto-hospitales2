package com.example.proyectohospital.adaptadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectohospital.R;
import com.example.proyectohospital.modelos.NotificacionCita;

import java.util.ArrayList;
import java.util.List;

public class NotificacionCitaAdapter extends RecyclerView.Adapter<NotificacionCitaAdapter.ViewHolder> {

    private List<NotificacionCita> notificaciones;
    private OnNotificacionCitaListener listener;

    public interface OnNotificacionCitaListener {
        void onConfirmarCita(NotificacionCita cita, int position);
        void onReprogramarCita(NotificacionCita cita, int position);
        void onCancelarCita(NotificacionCita cita, int position);
    }

    public NotificacionCitaAdapter(OnNotificacionCitaListener listener) {
        this.notificaciones = new ArrayList<>();
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_notificacion_cita, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        NotificacionCita notificacion = notificaciones.get(position);
        holder.bind(notificacion, position, listener);
    }

    @Override
    public int getItemCount() {
        return notificaciones.size();
    }

    public void setNotificaciones(List<NotificacionCita> notificaciones) {
        this.notificaciones = notificaciones;
        notifyDataSetChanged();
    }

    public void removeNotificacion(int position) {
        if (position >= 0 && position < notificaciones.size()) {
            notificaciones.remove(position);
            notifyItemRemoved(position);
        }
    }

    public void updateNotificacion(int position) {
        if (position >= 0 && position < notificaciones.size()) {
            notifyItemChanged(position);
        }
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private TextView tvTipo;
        private TextView tvNombreDoctor;
        private TextView tvEspecialidad;
        private TextView tvFechaCita;
        private TextView tvHoraCita;
        private TextView tvMensaje;
        private Button btnConfirmar;
        private Button btnReprogramar;
        private Button btnCancelar;
        private LinearLayout containerBotones;
        private View indicadorLeida;
        private ImageView imgEmojiTipo;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTipo = itemView.findViewById(R.id.tv_tipo_cita);
            tvNombreDoctor = itemView.findViewById(R.id.tv_nombre_doctor);
            tvEspecialidad = itemView.findViewById(R.id.tv_especialidad_doctor);
            tvFechaCita = itemView.findViewById(R.id.tv_fecha_cita);
            tvHoraCita = itemView.findViewById(R.id.tv_hora_cita);
            tvMensaje = itemView.findViewById(R.id.tv_mensaje_cita);
            btnConfirmar = itemView.findViewById(R.id.btn_confirmar_cita);
      //      btnReprogramar = itemView.findViewById(R.id.btn_reprogramar_cita);
            btnCancelar = itemView.findViewById(R.id.btn_cancelar_cita);
            containerBotones = itemView.findViewById(R.id.container_botones_cita);
            indicadorLeida = itemView.findViewById(R.id.indicador_leida_cita);
            imgEmojiTipo = itemView.findViewById(R.id.img_emoji_tipo);
        }

        public void bind(NotificacionCita notificacion, int position,
                         OnNotificacionCitaListener listener) {

            // Información básica
            tvTipo.setText(notificacion.getTituloTipo());
            tvNombreDoctor.setText(notificacion.getNombreCompletoDoctor());
            tvMensaje.setText(notificacion.getMensaje());

            // Especialidad
            if (notificacion.getEspecialidad() != null && !notificacion.getEspecialidad().isEmpty()) {
                tvEspecialidad.setText(notificacion.getEspecialidad());
                tvEspecialidad.setVisibility(View.VISIBLE);
            } else {
                tvEspecialidad.setVisibility(View.GONE);
            }

            // Fecha y hora - aquí se mostrará el formato correcto
            tvFechaCita.setText("📅 " + notificacion.getFechaCita());
            tvHoraCita.setText("⏰ " + notificacion.getHoraCita());

            // Emoji tipo
            if (imgEmojiTipo != null) {
                imgEmojiTipo.setContentDescription(notificacion.getEmojiTipo());
            }

            // Indicador de leída
            if (notificacion.isLeida()) {
                indicadorLeida.setAlpha(0.3f);
            } else {
                indicadorLeida.setAlpha(1f);
            }

            // Mostrar/ocultar botones según el tipo
            mostrarBotonesPorTipo(notificacion);

            // Listeners de botones
            btnConfirmar.setOnClickListener(v -> {
                listener.onConfirmarCita(notificacion, position);
            });

        //    btnReprogramar.setOnClickListener(v -> {
         //       listener.onReprogramarCita(notificacion, position);
          //  });

            btnCancelar.setOnClickListener(v -> {
                listener.onCancelarCita(notificacion, position);
            });

            // Click en el item completo para marcar como leído
            itemView.setOnClickListener(v -> {
                notificacion.setLeida(true);
                indicadorLeida.setAlpha(0.3f);
            });
        }

        private void mostrarBotonesPorTipo(NotificacionCita notificacion) {
            String tipo = notificacion.getTipo();

            btnConfirmar.setVisibility(View.GONE);
           // btnReprogramar.setVisibility(View.GONE);
            btnCancelar.setVisibility(View.GONE);

            switch (tipo) {
                case "recordatorio":
                    btnConfirmar.setVisibility(View.VISIBLE);
                   // btnReprogramar.setVisibility(View.VISIBLE);
                    btnCancelar.setVisibility(View.VISIBLE);
                    break;

                case "confirmacion":
                   // btnReprogramar.setVisibility(View.VISIBLE);
                    btnCancelar.setVisibility(View.VISIBLE);
                    break;

                case "cambio":
                    btnConfirmar.setVisibility(View.VISIBLE);
                    btnCancelar.setVisibility(View.VISIBLE);
                    break;

                case "cancelacion":
                    // No mostrar botones para cancelación
                    break;

                default:
                    btnConfirmar.setVisibility(View.VISIBLE);
                    break;
            }
        }
    }
}