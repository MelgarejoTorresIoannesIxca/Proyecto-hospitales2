package com.example.proyectohospital.Principal;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.proyectohospital.R;
import com.example.proyectohospital.adaptadores.NotificacionMedicamentoAdapter;
import com.example.proyectohospital.adaptadores.NotificacionCitaAdapter;
import com.example.proyectohospital.modelos.NotificacionMedicamento;
import com.example.proyectohospital.modelos.NotificacionCita;
import com.example.proyectohospital.servicios.NotificacionManager;
import java.util.ArrayList;
import java.util.List;

public class activity_notificaciones extends AppCompatActivity
        implements NotificacionMedicamentoAdapter.OnNotificacionListener,
        NotificacionCitaAdapter.OnNotificacionCitaListener {

    private static final String TAG = "NotificacionesActivity";

    private RecyclerView recyclerNotificaciones;
    private NotificacionMedicamentoAdapter adapterMedicamentos;
    private NotificacionCitaAdapter adapterCitas;
    private LinearLayout emptyState;
    private ImageView btnBack, btnMarkAllRead;
    private LinearLayout tabTodas, tabMedicamentos, tabCitas;
    private TextView txtTodas, txtMedicamentos, txtCitas;
    private View indicatorTodas, indicatorMedicamentos, indicatorCitas;
    private NotificacionManager notificacionManager;
    private String filtroActual = "todas";
    private int idPaciente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notificaciones);

        idPaciente = getIntent().getIntExtra("id_paciente", 21);
        Log.d(TAG, "ID Paciente: " + idPaciente);

        if (idPaciente == -1) {
            Toast.makeText(this, "⚠ Error: No se recibió el ID del paciente.",
                    Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        inicializarVistas();
        configurarRecyclerView();
        configurarListeners();
        notificacionManager = new NotificacionManager(this);

        sincronizarNotificaciones();
        cargarNotificaciones();
    }

    private void sincronizarNotificaciones() {
        Log.d(TAG, "Sincronizando notificaciones...");
        notificacionManager.sincronizarConServidor(idPaciente,
                (success, notificacionesSincronizadas) -> {
                    Log.d(TAG, "Sincronización resultado: " + success + ", notificaciones: " + notificacionesSincronizadas);
                    if (success && notificacionesSincronizadas > 0) {
                        cargarNotificaciones();
                        Toast.makeText(activity_notificaciones.this,
                                "Sincronizadas " + notificacionesSincronizadas + " notificaciones",
                                Toast.LENGTH_SHORT).show();
                    }
                });
    }

    private void inicializarVistas() {
        recyclerNotificaciones = findViewById(R.id.recycler_notificaciones);
        emptyState = findViewById(R.id.empty_state);
        btnBack = findViewById(R.id.btn_back);
        btnMarkAllRead = findViewById(R.id.btn_mark_all_read);
        tabTodas = findViewById(R.id.tab_todas);
        tabMedicamentos = findViewById(R.id.tab_medicamentos);
        tabCitas = findViewById(R.id.tab_citas);
        txtTodas = findViewById(R.id.txt_todas);
        txtMedicamentos = findViewById(R.id.txt_medicamentos);
        txtCitas = findViewById(R.id.txt_citas);
        indicatorTodas = findViewById(R.id.indicator_todas);
        indicatorMedicamentos = findViewById(R.id.indicator_medicamentos);
        indicatorCitas = findViewById(R.id.indicator_citas);
    }

    private void configurarRecyclerView() {
        adapterMedicamentos = new NotificacionMedicamentoAdapter(this);
        adapterCitas = new NotificacionCitaAdapter(this);
        recyclerNotificaciones.setLayoutManager(new LinearLayoutManager(this));
    }

    private void configurarListeners() {
        btnBack.setOnClickListener(v -> finish());

        btnMarkAllRead.setOnClickListener(v -> {
            notificacionManager.marcarTodasComoLeidas(idPaciente);
            cargarNotificaciones();
            Toast.makeText(this, "✓ Todas las notificaciones marcadas como leídas",
                    Toast.LENGTH_SHORT).show();
        });

        tabTodas.setOnClickListener(v -> cambiarFiltro("todas"));
        tabMedicamentos.setOnClickListener(v -> cambiarFiltro("medicamentos"));
        tabCitas.setOnClickListener(v -> cambiarFiltro("citas"));
    }

    private void cambiarFiltro(String filtro) {
        Log.d(TAG, "Cambiando filtro a: " + filtro);
        filtroActual = filtro;
        resetearPestanas();

        switch (filtro) {
            case "todas":
                activarPestana(txtTodas, indicatorTodas);
                break;
            case "medicamentos":
                activarPestana(txtMedicamentos, indicatorMedicamentos);
                break;
            case "citas":
                activarPestana(txtCitas, indicatorCitas);
                break;
        }
        cargarNotificaciones();
    }

    private void resetearPestanas() {
        desactivarPestana(txtTodas, indicatorTodas);
        desactivarPestana(txtMedicamentos, indicatorMedicamentos);
        desactivarPestana(txtCitas, indicatorCitas);
    }

    private void activarPestana(TextView texto, View indicador) {
        int color = getResources().getColor(android.R.color.holo_green_dark);
        texto.setTextColor(color);
        texto.setTypeface(null, android.graphics.Typeface.BOLD);
        indicador.setBackgroundColor(color);
    }

    private void desactivarPestana(TextView texto, View indicador) {
        texto.setTextColor(getResources().getColor(android.R.color.darker_gray));
        texto.setTypeface(null, android.graphics.Typeface.NORMAL);
        indicador.setBackgroundColor(getResources().getColor(android.R.color.transparent));
    }

    private void cargarNotificaciones() {
        Log.d(TAG, "Cargando notificaciones con filtro: " + filtroActual);

        switch (filtroActual) {
            case "medicamentos":
                cargarSoloMedicamentos();
                break;

            case "citas":
                cargarSoloCitas();
                break;

            default:
                cargarTodas();
                break;
        }
    }

    private void cargarSoloMedicamentos() {
        Log.d(TAG, "Cargando SOLO medicamentos...");
        List<NotificacionMedicamento> medics =
                notificacionManager.getNotificacionesMedicamentos(idPaciente);
        Log.d(TAG, "Medicamentos encontrados: " + medics.size());

        recyclerNotificaciones.setAdapter(adapterMedicamentos);
        adapterMedicamentos.setNotificaciones(medics);
        mostrarEstadoVacio(medics.isEmpty());
    }

    private void cargarSoloCitas() {
        Log.d(TAG, "Cargando SOLO citas...");
        List<NotificacionCita> citas =
                notificacionManager.getNotificacionesCitas(idPaciente);
        Log.d(TAG, "Citas encontradas: " + citas.size());

        if (!citas.isEmpty()) {
            Log.d(TAG, "Primera cita: tipo=" + citas.get(0).getTipo() +
                    ", hora=" + citas.get(0).getHoraCita() +
                    ", doctor=" + citas.get(0).getNombreCompletoDoctor());
        }

        recyclerNotificaciones.setAdapter(adapterCitas);
        adapterCitas.setNotificaciones(citas);
        mostrarEstadoVacio(citas.isEmpty());
    }

    private void cargarTodas() {
        Log.d(TAG, "Cargando TODAS las notificaciones...");
        List<NotificacionMedicamento> allMedics =
                notificacionManager.getTodasNotificaciones(idPaciente);
        List<NotificacionCita> allCitas =
                notificacionManager.getNotificacionesCitas(idPaciente);

        Log.d(TAG, "Medicamentos totales: " + allMedics.size());
        Log.d(TAG, "Citas totales: " + allCitas.size());

        // Si hay medicamentos, mostrarlos primero
        if (!allMedics.isEmpty()) {
            Log.d(TAG, "Mostrando medicamentos en vista todas");
            recyclerNotificaciones.setAdapter(adapterMedicamentos);
            adapterMedicamentos.setNotificaciones(allMedics);
            mostrarEstadoVacio(false);
        }
        // Si no hay medicamentos pero hay citas, mostrar citas
        else if (!allCitas.isEmpty()) {
            Log.d(TAG, "Mostrando citas en vista todas");
            recyclerNotificaciones.setAdapter(adapterCitas);
            adapterCitas.setNotificaciones(allCitas);
            mostrarEstadoVacio(false);
        }
        // Si no hay nada, mostrar estado vacío
        else {
            Log.d(TAG, "No hay notificaciones, mostrando estado vacío");
            mostrarEstadoVacio(true);
        }
    }

    private void mostrarEstadoVacio(boolean vacio) {
        Log.d(TAG, "mostrarEstadoVacio: " + vacio);
        if (vacio) {
            emptyState.setVisibility(View.VISIBLE);
            recyclerNotificaciones.setVisibility(View.GONE);
        } else {
            emptyState.setVisibility(View.GONE);
            recyclerNotificaciones.setVisibility(View.VISIBLE);
        }
    }

    // ========== LISTENERS MEDICAMENTOS ==========

    @Override
    public void onMarcarTomado(NotificacionMedicamento notificacion, int position) {
        notificacion.setTomado(true);
        notificacion.setLeida(true);
        notificacionManager.actualizarNotificacion(notificacion);
        adapterMedicamentos.updateNotificacion(position);
        Toast.makeText(this, "✓ Medicamento marcado como tomado", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onPosponer(NotificacionMedicamento notificacion, int position) {
        long nuevaHora = System.currentTimeMillis() + (15 * 60 * 1000);
        notificacion.setTimestamp(nuevaHora);
        notificacionManager.posponerNotificacion(notificacion, 15);
        adapterMedicamentos.removeNotificacion(position);
        Toast.makeText(this, "⏱ Recordatorio pospuesto 15 minutos", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNotificacionClick(NotificacionMedicamento notificacion, int position) {
        notificacion.setLeida(true);
        notificacionManager.actualizarNotificacion(notificacion);
        adapterMedicamentos.updateNotificacion(position);
    }

    // ========== LISTENERS CITAS ==========

    @Override
    public void onConfirmarCita(NotificacionCita cita, int position) {
        notificacionManager.confirmarCita(cita.getIdCita());
        adapterCitas.removeNotificacion(position);
        Toast.makeText(this, "✓ Cita confirmada", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onReprogramarCita(NotificacionCita cita, int position) {
        Toast.makeText(this, "📅 Abriendo opciones de reprogramación", Toast.LENGTH_SHORT).show();
        // TODO: Implementar diálogo de reprogramación
    }

    @Override
    public void onCancelarCita(NotificacionCita cita, int position) {
        notificacionManager.cancelarCita(cita.getIdCita(), idPaciente);
        adapterCitas.removeNotificacion(position);
        Toast.makeText(this, "✗ Cita cancelada", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume - recargando notificaciones");
        cargarNotificaciones();
    }
}