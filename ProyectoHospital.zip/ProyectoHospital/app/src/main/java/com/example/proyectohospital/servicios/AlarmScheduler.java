package com.example.proyectohospital.servicios;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.util.Log;
import android.widget.Toast;
import com.example.proyectohospital.modelos.MedicamentoResponse;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class AlarmScheduler {

    private static final String TAG = "AlarmScheduler";

    /**
     * Programa alarmas para todos los medicamentos de la lista
     * @param context Contexto de la aplicación
     * @param medicamentos Lista de medicamentos con sus horarios
     * @param idPaciente ID del paciente
     */
    public static void programarAlarmas(Context context, List<MedicamentoResponse> medicamentos, int idPaciente) {
        if (context == null || medicamentos == null || medicamentos.isEmpty()) {
            Log.w(TAG, "No se pueden programar alarmas: contexto o lista vacía");
            return;
        }

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            Log.e(TAG, "No se pudo obtener AlarmManager");
            return;
        }

        int alarmasProgramadas = 0;

        for (MedicamentoResponse medicamento : medicamentos) {
            String horasToma = medicamento.getHorasToma();

            if (horasToma == null || horasToma.trim().isEmpty()) {
                Log.w(TAG, "Medicamento sin horas de toma: " + medicamento.getNombre());
                continue;
            }

            // Dividir las horas separadas por comas: "08:00,14:00,20:00"
            String[] horas = horasToma.split(",");

            for (String hora : horas) {
                hora = hora.trim(); // Eliminar espacios

                if (hora.isEmpty()) {
                    continue;
                }

                try {
                    // Programar alarma para esta hora específica
                    boolean programada = programarAlarmaIndividual(
                            context,
                            alarmManager,
                            medicamento,
                            hora,
                            idPaciente
                    );

                    if (programada) {
                        alarmasProgramadas++;
                        Log.d(TAG, "Alarma programada: " + medicamento.getNombre() + " a las " + hora);
                    }

                } catch (Exception e) {
                    Log.e(TAG, "Error al programar alarma para " + medicamento.getNombre() + " a las " + hora, e);
                }
            }
        }

        Log.i(TAG, "Total de alarmas programadas: " + alarmasProgramadas);

        if (alarmasProgramadas > 0) {
            Toast.makeText(context,
                    "Se programaron " + alarmasProgramadas + " recordatorios",
                    Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * Programa una alarma individual para un medicamento a una hora específica
     */
    private static boolean programarAlarmaIndividual(Context context,
                                                     AlarmManager alarmManager,
                                                     MedicamentoResponse medicamento,
                                                     String hora,
                                                     int idPaciente) {
        try {
            // Calcular el timestamp para la hora indicada
            long timestamp = calcularTimestamp(hora);

            if (timestamp <= System.currentTimeMillis()) {
                Log.w(TAG, "La hora " + hora + " ya pasó hoy, no se programa alarma");
                return false;
            }

            // Crear un ID único para cada alarma
            int notificationId = generarIdNotificacion(medicamento.getNombre(), hora, idPaciente);

            // Crear el Intent con los datos del medicamento
            Intent intent = new Intent(context, AlarmReceiver.class);
            intent.putExtra("nombre_medicamento", medicamento.getNombre());
            intent.putExtra("dosis", medicamento.getDosis());
            intent.putExtra("hora_toma", hora);
            intent.putExtra("id_paciente", idPaciente);
            intent.putExtra("notification_id", notificationId);

            // Crear PendingIntent
            PendingIntent pendingIntent = PendingIntent.getBroadcast(
                    context,
                    notificationId,
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );

            // Programar la alarma según la versión de Android
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                // Android 6.0+ (Marshmallow)
                alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        timestamp,
                        pendingIntent
                );
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                // Android 4.4+ (KitKat)
                alarmManager.setExact(
                        AlarmManager.RTC_WAKEUP,
                        timestamp,
                        pendingIntent
                );
            } else {
                // Android anterior a 4.4
                alarmManager.set(
                        AlarmManager.RTC_WAKEUP,
                        timestamp,
                        pendingIntent
                );
            }

            return true;

        } catch (Exception e) {
            Log.e(TAG, "Error al programar alarma individual", e);
            return false;
        }
    }

    /**
     * Calcula el timestamp (milisegundos) para una hora específica del día de hoy
     * @param hora Hora en formato "HH:mm" (ejemplo: "08:00", "14:30")
     * @return Timestamp en milisegundos
     */
    private static long calcularTimestamp(String hora) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
        Date horaDate = sdf.parse(hora);

        if (horaDate == null) {
            throw new ParseException("No se pudo parsear la hora: " + hora, 0);
        }

        // Obtener el calendario de hoy
        Calendar calendar = Calendar.getInstance();

        // Obtener la hora parseada
        Calendar horaCalendar = Calendar.getInstance();
        horaCalendar.setTime(horaDate);

        // Establecer la hora, minutos y segundos
        calendar.set(Calendar.HOUR_OF_DAY, horaCalendar.get(Calendar.HOUR_OF_DAY));
        calendar.set(Calendar.MINUTE, horaCalendar.get(Calendar.MINUTE));
        calendar.set(Calendar.SECOND, 0);
        calendar.set(Calendar.MILLISECOND, 0);

        return calendar.getTimeInMillis();
    }

    /**
     * Genera un ID único para cada notificación basado en el medicamento y la hora
     * @param nombreMedicamento Nombre del medicamento
     * @param hora Hora de la toma
     * @param idPaciente ID del paciente
     * @return ID único
     */
    private static int generarIdNotificacion(String nombreMedicamento, String hora, int idPaciente) {
        // Crear un hash único combinando el nombre, hora y paciente
        String combinacion = nombreMedicamento + hora + idPaciente;
        return Math.abs(combinacion.hashCode());
    }

    /**
     * Cancela una alarma específica
     * @param context Contexto
     * @param nombreMedicamento Nombre del medicamento
     * @param hora Hora de la toma
     * @param idPaciente ID del paciente
     */
    public static void cancelarAlarma(Context context, String nombreMedicamento, String hora, int idPaciente) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }

        int notificationId = generarIdNotificacion(nombreMedicamento, hora, idPaciente);

        Intent intent = new Intent(context, AlarmReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                notificationId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        alarmManager.cancel(pendingIntent);
        Log.d(TAG, "Alarma cancelada: " + nombreMedicamento + " a las " + hora);
    }

    /**
     * Cancela todas las alarmas de un paciente
     * @param context Contexto
     * @param medicamentos Lista de medicamentos
     * @param idPaciente ID del paciente
     */
    public static void cancelarTodasLasAlarmas(Context context, List<MedicamentoResponse> medicamentos, int idPaciente) {
        if (medicamentos == null || medicamentos.isEmpty()) {
            return;
        }

        int alarmasCanceladas = 0;

        for (MedicamentoResponse medicamento : medicamentos) {
            String horasToma = medicamento.getHorasToma();

            if (horasToma == null || horasToma.trim().isEmpty()) {
                continue;
            }

            String[] horas = horasToma.split(",");

            for (String hora : horas) {
                hora = hora.trim();
                if (!hora.isEmpty()) {
                    cancelarAlarma(context, medicamento.getNombre(), hora, idPaciente);
                    alarmasCanceladas++;
                }
            }
        }

        Log.i(TAG, "Total de alarmas canceladas: " + alarmasCanceladas);
        Toast.makeText(context, "Recordatorios cancelados", Toast.LENGTH_SHORT).show();
    }

    /**
     * Reprograma una alarma (útil para la función posponer)
     * @param context Contexto
     * @param nombreMedicamento Nombre del medicamento
     * @param dosis Dosis del medicamento
     * @param hora Hora original
     * @param minutosAPosponer Minutos a posponer
     * @param idPaciente ID del paciente
     */
    public static void reprogramarAlarma(Context context, String nombreMedicamento, String dosis,
                                         String hora, int minutosAPosponer, int idPaciente) {
        // Primero cancelar la alarma existente
        cancelarAlarma(context, nombreMedicamento, hora, idPaciente);

        // Calcular nueva hora
        long nuevoTimestamp = System.currentTimeMillis() + (minutosAPosponer * 60 * 1000L);

        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) {
            return;
        }

        int notificationId = generarIdNotificacion(nombreMedicamento, hora, idPaciente);

        Intent intent = new Intent(context, AlarmReceiver.class);
        intent.putExtra("nombre_medicamento", nombreMedicamento);
        intent.putExtra("dosis", dosis);
        intent.putExtra("hora_toma", hora);
        intent.putExtra("id_paciente", idPaciente);
        intent.putExtra("notification_id", notificationId);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                notificationId,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    nuevoTimestamp,
                    pendingIntent
            );
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            alarmManager.setExact(
                    AlarmManager.RTC_WAKEUP,
                    nuevoTimestamp,
                    pendingIntent
            );
        }

        Log.d(TAG, "Alarma reprogramada: " + nombreMedicamento + " para dentro de " + minutosAPosponer + " minutos");
    }}
