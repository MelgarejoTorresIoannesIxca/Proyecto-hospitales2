package com.example.proyectohospital.modelos;

public class LoginResponse {
    public String status;
    public String mensaje;
    public UsuarioLogin usuario;  // ← Cambio: usar UsuarioLogin en lugar de Usuario

    public LoginResponse() {
    }

    public LoginResponse(String status, String mensaje, UsuarioLogin usuario) {
        this.status = status;
        this.mensaje = mensaje;
        this.usuario = usuario;
    }
}


