package com.example.proyectohospital.calendario;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectohospital.R;
import com.example.proyectohospital.adaptadores.MedicamentoAdapter;
import com.example.proyectohospital.modelos.MedicamentoResponse;
import com.example.proyectohospital.navegacion.ApiService;
import com.example.proyectohospital.navegacion.RetrofitClient;
import com.example.proyectohospital.servicios.AlarmScheduler;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MedicamentosFragment extends Fragment {

    private static final String TAG = "MedicamentosFragment";
    private static final String ARG_FECHA = "fecha";

    private RecyclerView recyclerMedicamentos;
    private MedicamentoAdapter adapter;
    private List<MedicamentoResponse> listaMedicamentos = new ArrayList<>();

    private String fecha;
    private int idPaciente;

    public MedicamentosFragment() {}

    public static MedicamentosFragment newInstance(String fecha) {
        MedicamentosFragment fragment = new MedicamentosFragment();
        Bundle args = new Bundle();
        args.putString(ARG_FECHA, fecha);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ⭐ OBTENER idPaciente DESDE LA SESIÓN
        SharedPreferences prefs = requireActivity().getSharedPreferences("SesionUsuario", Context.MODE_PRIVATE);
        idPaciente = prefs.getInt("idUsuarios", 0);

        if (getArguments() != null) {
            fecha = getArguments().getString(ARG_FECHA);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_medicamentos, container, false);

        recyclerMedicamentos = view.findViewById(R.id.recyclerMedicamentos);
        adapter = new MedicamentoAdapter(listaMedicamentos);
        recyclerMedicamentos.setAdapter(adapter);
        recyclerMedicamentos.setLayoutManager(new LinearLayoutManager(getContext()));

        if (fecha != null) {
            cargarMedicamentos(idPaciente, fecha);
        }

        return view;
    }

    public void actualizarMedicamentos(String nuevaFecha) {
        this.fecha = nuevaFecha;
        cargarMedicamentos(idPaciente, nuevaFecha);
    }

    private void cargarMedicamentos(int idPaciente, String fecha) {

        ApiService api = RetrofitClient.getClient().create(ApiService.class);

        api.getMedicamentos(idPaciente, fecha).enqueue(new Callback<List<MedicamentoResponse>>() {
            @Override
            public void onResponse(Call<List<MedicamentoResponse>> call, Response<List<MedicamentoResponse>> response) {

                if (response.isSuccessful() && response.body() != null) {

                    List<MedicamentoResponse> meds = response.body();
                    Log.d(TAG, "Medicamentos recibidos: " + meds.size());

                    adapter.setMedicamentos(meds);

                    // ⭐ PROGRAMAR ALARMAS
                    AlarmScheduler.programarAlarmas(getContext(), meds, idPaciente);

                } else {
                    Log.d(TAG, "No se recibieron medicamentos para la fecha: " + fecha);
                    adapter.setMedicamentos(new ArrayList<>());
                }
            }

            @Override
            public void onFailure(Call<List<MedicamentoResponse>> call, Throwable t) {
                Log.e(TAG, "Error al conectar con el servidor: " + t.getMessage());
                if (getContext() != null) {
                    Toast.makeText(getContext(), "Error al conectar con el servidor", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}
