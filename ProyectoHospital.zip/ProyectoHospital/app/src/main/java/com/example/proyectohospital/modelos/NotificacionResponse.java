package com.example.proyectohospital.modelos;

public class NotificacionResponse {
    private int id;
    private String nombreMedicamento;
    private String dosis;
    private String horaToma;
    private String fecha;
    private int idPaciente;
    private boolean leida;
    private boolean tomado;

    // Constructor vacío
    public NotificacionResponse() {
    }

    // Constructor completo
    public NotificacionResponse(int id, String nombreMedicamento, String dosis,
                                String horaToma, String fecha, int idPaciente,
                                boolean leida, boolean tomado) {
        this.id = id;
        this.nombreMedicamento = nombreMedicamento;
        this.dosis = dosis;
        this.horaToma = horaToma;
        this.fecha = fecha;
        this.idPaciente = idPaciente;
        this.leida = leida;
        this.tomado = tomado;
    }

    // Getters
    public int getId() {
        return id;
    }

    public String getNombreMedicamento() {
        return nombreMedicamento;
    }

    public String getDosis() {
        return dosis;
    }

    public String getHoraToma() {
        return horaToma;
    }

    public String getFecha() {
        return fecha;
    }

    public int getIdPaciente() {
        return idPaciente;
    }

    public boolean isLeida() {
        return leida;
    }

    public boolean isTomado() {
        return tomado;
    }

    // Setters
    public void setId(int id) {
        this.id = id;
    }

    public void setNombreMedicamento(String nombreMedicamento) {
        this.nombreMedicamento = nombreMedicamento;
    }

    public void setDosis(String dosis) {
        this.dosis = dosis;
    }

    public void setHoraToma(String horaToma) {
        this.horaToma = horaToma;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public void setIdPaciente(int idPaciente) {
        this.idPaciente = idPaciente;
    }

    public void setLeida(boolean leida) {
        this.leida = leida;
    }

    public void setTomado(boolean tomado) {
        this.tomado = tomado;
    }

    @Override
    public String toString() {
        return "NotificacionResponse{" +
                "id=" + id +
                ", nombreMedicamento='" + nombreMedicamento + '\'' +
                ", dosis='" + dosis + '\'' +
                ", horaToma='" + horaToma + '\'' +
                ", fecha='" + fecha + '\'' +
                ", idPaciente=" + idPaciente +
                ", leida=" + leida +
                ", tomado=" + tomado +
                '}';
    }
}