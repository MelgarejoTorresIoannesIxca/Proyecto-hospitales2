package com.example.proyectohospital.modelos;

public class UsuarioInfo {
    public String mensaje;
    public int exito;
}
