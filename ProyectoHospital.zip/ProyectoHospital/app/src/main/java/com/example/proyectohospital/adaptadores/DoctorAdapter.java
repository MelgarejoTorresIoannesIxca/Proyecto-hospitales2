package com.example.proyectohospital.adaptadores;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.proyectohospital.Principal.DetalleDoctorActivity;
import com.example.proyectohospital.R;
import com.example.proyectohospital.modelos.Doctor;

import java.util.ArrayList;
import java.util.List;

public class DoctorAdapter extends RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder> {

    private Context context;
    private List<Doctor> doctores = new ArrayList<>();

    public DoctorAdapter(Context context) {
        this.context = context;
    }

    public void setDoctores(List<Doctor> doctores) {
        this.doctores = doctores;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public DoctorViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.doctor_card, parent, false);
        return new DoctorViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull DoctorViewHolder holder, int position) {
        Doctor doctor = doctores.get(position);

        holder.tvNombre.setText(doctor.getNombreCompleto());

        holder.tvEspecialidad.setText(
                doctor.getEspecialidades() != null ? doctor.getEspecialidades() : "Sin especialidad"
        );

        holder.tvCalificacion.setText("⭐ " + doctor.getCalificacion());
        holder.tvResenas.setText(doctor.getCantidadResenas() + " reseñas");

        // CLICK → abrir pantalla de detalle
        holder.itemView.setOnClickListener(v -> {
            Intent intent = new Intent(context, DetalleDoctorActivity.class);

            intent.putExtra("nombre", doctor.getNombreCompleto());
            intent.putExtra("especialidad", doctor.getEspecialidades());
            intent.putExtra("calificacion", doctor.getCalificacion());
            intent.putExtra("resenas", doctor.getCantidadResenas());

            context.startActivity(intent);
        });
    }

    @Override
    public int getItemCount() {
        return doctores.size();
    }

    static class DoctorViewHolder extends RecyclerView.ViewHolder {
        TextView tvNombre, tvEspecialidad, tvCalificacion, tvResenas;

        public DoctorViewHolder(@NonNull View itemView) {
            super(itemView);
            tvNombre = itemView.findViewById(R.id.tvDoctorNombre);
            tvEspecialidad = itemView.findViewById(R.id.tvDoctorEspecialidad);
            tvCalificacion = itemView.findViewById(R.id.tvDoctorCalificacion);
            tvResenas = itemView.findViewById(R.id.tvDoctorResenas);
        }
    }
}
