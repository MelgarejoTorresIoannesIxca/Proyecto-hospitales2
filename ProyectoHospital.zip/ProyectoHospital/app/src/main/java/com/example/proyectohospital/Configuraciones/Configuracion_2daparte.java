package com.example.proyectohospital.Configuraciones;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.proyectohospital.R;
import com.example.proyectohospital.Principal.MainPrincipalCliente;

public class Configuracion_2daparte extends AppCompatActivity {

    LinearLayout itemNotificacion, itemContrasena;
    ImageButton btnBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Activar EdgeToEdge
        setContentView(R.layout.activity_configuracion2daparte); // <-- XML correcto
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // ============================
        // Inicializar views
        // ============================
        btnBack = findViewById(R.id.btnBack);
        itemNotificacion = findViewById(R.id.itemNotificacion);
        itemContrasena = findViewById(R.id.itemContrasena);

        // ============================
        // Eventos click
        // ============================
        btnBack.setOnClickListener(v -> finish()); // Regresar a la activity anterior

        itemNotificacion.setOnClickListener(v -> {
            // Abrir actividad para administrar perfil
            startActivity(new Intent(Configuracion_2daparte.this, Perfil.class));
        });

        itemContrasena.setOnClickListener(v -> {
            // Abrir actividad para administrar contraseña
            startActivity(new Intent(Configuracion_2daparte.this, Configuracion_password.class));
        });
    }
}
