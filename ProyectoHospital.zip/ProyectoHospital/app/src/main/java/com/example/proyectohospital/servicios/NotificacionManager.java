package com.example.proyectohospital.servicios;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

import com.example.proyectohospital.modelos.NotificacionCita;
import com.example.proyectohospital.modelos.NotificacionMedicamento;
import com.example.proyectohospital.modelos.NotificacionResponse;
import com.example.proyectohospital.modelos.CitaRequest;
import com.example.proyectohospital.modelos.MensajeResponse;
import com.example.proyectohospital.navegacion.ApiService;
import com.example.proyectohospital.navegacion.RetrofitClient;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class NotificacionManager {

    private static final String PREFS_NAME = "NotificacionesPrefs";
    private static final String KEY_NOTIFICACIONES_MEDICS = "notificaciones_medicamentos";
    private static final String KEY_NOTIFICACIONES_CITAS = "notificaciones_citas";
    private static final String TAG = "NotificacionManager";

    private SharedPreferences prefs;
    private Gson gson;
    private Context context;

    public NotificacionManager(Context context) {
        this.context = context;
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    // ==============================
    // MÉTODOS NOTIFICACIONES MEDICAMENTOS
    // ==============================

    public void agregarNotificacion(NotificacionMedicamento notificacion) {
        List<NotificacionMedicamento> global = getTodasNotificacionesGlobal();
        global.add(0, notificacion);
        guardarNotificaciones(global);
    }

    public List<NotificacionMedicamento> getTodasNotificaciones(int idPaciente) {
        return getTodasNotificacionesGlobal().stream()
                .filter(n -> n.getIdPaciente() == idPaciente)
                .collect(Collectors.toList());
    }

    public List<NotificacionMedicamento> getNotificacionesMedicamentos(int idPaciente) {
        return getTodasNotificaciones(idPaciente).stream()
                .filter(n -> n.getNombreMedicamento() != null && !n.getNombreMedicamento().isEmpty())
                .collect(Collectors.toList());
    }

    public List<NotificacionMedicamento> getNotificacionesNoLeidas(int idPaciente) {
        return getTodasNotificaciones(idPaciente).stream()
                .filter(n -> !n.isLeida())
                .collect(Collectors.toList());
    }

    public int contarNoLeidas(int idPaciente) {
        int countMedic = getNotificacionesNoLeidas(idPaciente).size();
        int countCitas = getNotificacionesCitas(idPaciente).stream()
                .filter(c -> !c.isLeida())
                .collect(Collectors.toList()).size();
        return countMedic + countCitas;
    }

    public void actualizarNotificacion(NotificacionMedicamento notificacion) {
        List<NotificacionMedicamento> global = getTodasNotificacionesGlobal();
        for (int i = 0; i < global.size(); i++) {
            if (global.get(i).getId() == notificacion.getId()) {
                global.set(i, notificacion);
                break;
            }
        }
        guardarNotificaciones(global);
    }

    public void posponerNotificacion(NotificacionMedicamento notificacion, int minutos) {
        long nuevaHora = System.currentTimeMillis() + (minutos * 60 * 1000);
        notificacion.setTimestamp(nuevaHora);
        notificacion.setLeida(false);
        actualizarNotificacion(notificacion);
    }

    public void marcarTodasComoLeidas(int idPaciente) {
        List<NotificacionMedicamento> global = getTodasNotificacionesGlobal();
        for (NotificacionMedicamento n : global) {
            if (n.getIdPaciente() == idPaciente) n.setLeida(true);
        }
        guardarNotificaciones(global);

        // Marcamos también las citas como leídas
        List<NotificacionCita> citas = getNotificacionesCitas(idPaciente);
        for (NotificacionCita c : citas) c.setLeida(true);
        guardarNotificacionesCitas(citas);
    }

    public void eliminarNotificacion(int id) {
        List<NotificacionMedicamento> global = getTodasNotificacionesGlobal();
        global.removeIf(n -> n.getId() == id);
        guardarNotificaciones(global);
    }

    public void limpiarNotificacionesAntiguas(int idPaciente) {
        List<NotificacionMedicamento> global = getTodasNotificacionesGlobal();
        long hace7Dias = System.currentTimeMillis() - (7L * 24 * 60 * 60 * 1000);
        global.removeIf(n -> n.getIdPaciente() == idPaciente && n.isTomado() && n.getTimestamp() < hace7Dias);
        guardarNotificaciones(global);
    }

    // ==============================
    // MÉTODOS NOTIFICACIONES CITAS
    // ==============================

    public List<NotificacionCita> getNotificacionesCitas(int idPaciente) {
        String json = prefs.getString(KEY_NOTIFICACIONES_CITAS, "[]");
        Type type = new TypeToken<List<NotificacionCita>>(){}.getType();
        List<NotificacionCita> lista = gson.fromJson(json, type);

        Log.d(TAG, "📋 getNotificacionesCitas - JSON guardado tiene " + (lista != null ? lista.size() : 0) + " citas");

        if (lista == null) lista = new ArrayList<>();

        List<NotificacionCita> filtradas = lista.stream()
                .filter(c -> {
                    Log.d(TAG, "  Filtrando: idCita=" + c.getIdCita() + ", idPaciente=" + c.getIdPaciente() + ", buscando=" + idPaciente);
                    return c.getIdPaciente() == idPaciente;
                })
                .collect(Collectors.toList());

        Log.d(TAG, "✓ Citas filtradas para paciente " + idPaciente + ": " + filtradas.size());
        return filtradas;
    }

    public void guardarNotificacionesCitas(List<NotificacionCita> notificaciones) {
        String json = gson.toJson(notificaciones);
        prefs.edit().putString(KEY_NOTIFICACIONES_CITAS, json).apply();
        Log.d(TAG, "💾 Guardadas " + notificaciones.size() + " citas en SharedPreferences");
    }

    public void confirmarCita(int idCita) {
        ApiService api = RetrofitClient.getClient().create(ApiService.class);
        api.marcarNotificacionCitaLeida(idCita).enqueue(new Callback<MensajeResponse>() {
            @Override
            public void onResponse(Call<MensajeResponse> call, Response<MensajeResponse> response) {
                if (response.isSuccessful()) {
                    Log.d(TAG, "✓ Cita confirmada");
                    Toast.makeText(context, "✓ Cita confirmada", Toast.LENGTH_SHORT).show();
                } else {
                    Log.e(TAG, "Error: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<MensajeResponse> call, Throwable t) {
                Log.e(TAG, "Error al confirmar cita: " + t.getMessage());
                Toast.makeText(context, "Error al confirmar cita", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void cancelarCita(int idCita, int idPaciente) {
        ApiService api = RetrofitClient.getClient().create(ApiService.class);
        api.cancelarCita(idCita, idPaciente).enqueue(new Callback<MensajeResponse>() {
            @Override
            public void onResponse(Call<MensajeResponse> call, Response<MensajeResponse> response) {
                if (response.isSuccessful()) {
                    Log.d(TAG, "✗ Cita cancelada");
                    Toast.makeText(context, "✗ Cita cancelada", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<MensajeResponse> call, Throwable t) {
                Log.e(TAG, "Error al cancelar cita: " + t.getMessage());
                Toast.makeText(context, "Error al cancelar cita", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void reprogramarCita(int idCita, String nuevaFecha, String nuevaHora, int idPaciente) {
        ApiService api = RetrofitClient.getClient().create(ApiService.class);
        CitaRequest citaRequest = new CitaRequest(idPaciente, 0, nuevaFecha, nuevaHora, null, null);
        api.actualizarCita(idCita, citaRequest).enqueue(new Callback<MensajeResponse>() {
            @Override
            public void onResponse(Call<MensajeResponse> call, Response<MensajeResponse> response) {
                if (response.isSuccessful()) {
                    Log.d(TAG, "📅 Cita reprogramada");
                    Toast.makeText(context, "📅 Cita reprogramada", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<MensajeResponse> call, Throwable t) {
                Log.e(TAG, "Error al reprogramar cita: " + t.getMessage());
                Toast.makeText(context, "Error al reprogramar cita", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void marcarNotificacionCitaLeida(int idNotificacion) {
        ApiService api = RetrofitClient.getClient().create(ApiService.class);
        api.marcarNotificacionCitaLeida(idNotificacion).enqueue(new Callback<MensajeResponse>() {
            @Override
            public void onResponse(Call<MensajeResponse> call, Response<MensajeResponse> response) {
                Log.d(TAG, "Notificación marcada como leída");
            }

            @Override
            public void onFailure(Call<MensajeResponse> call, Throwable t) {
                Log.e(TAG, "Error al marcar notificación: " + t.getMessage());
                Toast.makeText(context, "Error al marcar notificación", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // ==============================
    // MÉTODOS PRIVADOS
    // ==============================

    private List<NotificacionMedicamento> getTodasNotificacionesGlobal() {
        String json = prefs.getString(KEY_NOTIFICACIONES_MEDICS, "[]");
        Type type = new TypeToken<List<NotificacionMedicamento>>(){}.getType();
        List<NotificacionMedicamento> lista = gson.fromJson(json, type);
        return lista != null ? lista : new ArrayList<>();
    }

    private void guardarNotificaciones(List<NotificacionMedicamento> notificaciones) {
        String json = gson.toJson(notificaciones);
        prefs.edit().putString(KEY_NOTIFICACIONES_MEDICS, json).apply();
    }

    public int generarNuevoId() {
        List<NotificacionMedicamento> global = getTodasNotificacionesGlobal();
        int maxId = 0;
        for (NotificacionMedicamento n : global) {
            if (n.getId() > maxId) maxId = n.getId();
        }
        return maxId + 1;
    }

    // ==============================
    // SINCRONIZAR CON EL SERVIDOR
    // ==============================

    public void sincronizarConServidor(int idPaciente, SyncCallback callback) {
        ApiService api = RetrofitClient.getClient().create(ApiService.class);

        // 🔹 Notificaciones medicamentos
        api.getHistorialNotificaciones(idPaciente).enqueue(new Callback<List<NotificacionResponse>>() {
            @Override
            public void onResponse(Call<List<NotificacionResponse>> call, Response<List<NotificacionResponse>> response) {
                if (!response.isSuccessful() || response.body() == null) {
                    Log.e(TAG, "Error medicamentos: " + response.code());
                    if (callback != null) callback.onSyncComplete(true, 0);
                    return;
                }

                List<NotificacionResponse> servidor = response.body();
                List<NotificacionMedicamento> global = getTodasNotificacionesGlobal();
                int agregadas = 0;

                for (NotificacionResponse s : servidor) {
                    boolean existe = global.stream().anyMatch(n -> n.getId() == s.getId());
                    if (!existe) {
                        NotificacionMedicamento nueva = new NotificacionMedicamento(
                                s.getId(),
                                s.getNombreMedicamento(),
                                s.getDosis(),
                                s.getHoraToma(),
                                System.currentTimeMillis(),
                                s.getIdPaciente()
                        );
                        nueva.setLeida(s.isLeida());
                        nueva.setTomado(s.isTomado());
                        global.add(nueva);
                        agregadas++;
                    }
                }

                guardarNotificaciones(global);
                Log.d(TAG, "Medicamentos sincronizados: " + agregadas);
                if (callback != null) callback.onSyncComplete(true, agregadas);
            }

            @Override
            public void onFailure(Call<List<NotificacionResponse>> call, Throwable t) {
                Log.e(TAG, "Error sincronizar medicamentos: " + t.getMessage());
                if (callback != null) callback.onSyncComplete(true, 0);
            }
        });

        // 🔹 Notificaciones citas
        api.getNotificacionesCitas(idPaciente).enqueue(new Callback<List<NotificacionCita>>() {
            @Override
            public void onResponse(Call<List<NotificacionCita>> call, Response<List<NotificacionCita>> response) {
                if (response.isSuccessful() && response.body() != null) {
                    List<NotificacionCita> citas = response.body();
                    guardarNotificacionesCitas(citas);
                    Log.d(TAG, "✓ Citas sincronizadas: " + citas.size());
                    for (NotificacionCita c : citas) {
                        Log.d(TAG, "  - Cita: " + c.getIdCita() + " - " + c.getNombreCompletoDoctor() + " - " + c.getHoraCita());
                    }
                } else {
                    Log.e(TAG, " Error citas: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<List<NotificacionCita>> call, Throwable t) {
                Log.e(TAG, " Error sincronizar citas: " + t.getMessage());
            }
        });
    }

    public interface SyncCallback {
        void onSyncComplete(boolean success, int notificacionesSincronizadas);
    }
}