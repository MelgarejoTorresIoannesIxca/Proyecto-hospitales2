package com.example.proyectohospital.modelos;

public class ChatMensaje {
    private int idMensaje;
    private int idConversacion;
    private String tipo; // usuario, asistente, sugerencia
    private String contenido;
    private String tipoSugerencia;
    private String metadatos;
    private String fechaEnvio;
    private boolean leido;

    public ChatMensaje() {}

    public ChatMensaje(String tipo, String contenido) {
        this.tipo = tipo;
        this.contenido = contenido;
    }

    // Getters y Setters
    public int getIdMensaje() { return idMensaje; }
    public void setIdMensaje(int idMensaje) { this.idMensaje = idMensaje; }

    public int getIdConversacion() { return idConversacion; }
    public void setIdConversacion(int idConversacion) { this.idConversacion = idConversacion; }

    public String getTipo() { return tipo; }
    public void setTipo(String tipo) { this.tipo = tipo; }

    public String getContenido() { return contenido; }
    public void setContenido(String contenido) { this.contenido = contenido; }

    public String getTipoSugerencia() { return tipoSugerencia; }
    public void setTipoSugerencia(String tipoSugerencia) { this.tipoSugerencia = tipoSugerencia; }

    public String getMetadatos() { return metadatos; }
    public void setMetadatos(String metadatos) { this.metadatos = metadatos; }

    public String getFechaEnvio() { return fechaEnvio; }
    public void setFechaEnvio(String fechaEnvio) { this.fechaEnvio = fechaEnvio; }

    public boolean isLeido() { return leido; }
    public void setLeido(boolean leido) { this.leido = leido; }

    public boolean esDelUsuario() {
        return "usuario".equals(tipo);
    }

    public boolean esDelAsistente() {
        return "asistente".equals(tipo);
    }
}