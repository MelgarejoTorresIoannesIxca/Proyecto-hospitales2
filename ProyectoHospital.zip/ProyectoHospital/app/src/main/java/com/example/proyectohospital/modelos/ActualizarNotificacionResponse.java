package com.example.proyectohospital.modelos;

// ========== Clase para respuesta de actualización de notificación ==========
public class ActualizarNotificacionResponse {
    private String status;
    private String mensaje;
    private int id;

    public ActualizarNotificacionResponse() {
    }

    public ActualizarNotificacionResponse(String status, String mensaje, int id) {
        this.status = status;
        this.mensaje = mensaje;
        this.id = id;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return "ActualizarNotificacionResponse{" +
                "status='" + status + '\'' +
                ", mensaje='" + mensaje + '\'' +
                ", id=" + id +
                '}';
    }
}

// ========== Clase para respuestas con mensaje simple ==========

// ========== Clase para contador de notificaciones ==========
