package com.example.proyectohospital.Principal;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.example.proyectohospital.Configuraciones.Perfil;
import com.example.proyectohospital.R;
import com.example.proyectohospital.calendario.Activity_Calendario;
import com.example.proyectohospital.servicios.AlarmReceiver;

public class MainPrincipalCliente extends AppCompatActivity {

    private static final String TAG = "MainPrincipalCliente";
    private static final String PREF_NAME = "SesionUsuario";
    private static final String KEY_ID_USUARIO = "idUsuarios";

    private LinearLayout btnDoctores, btnFavoritos, btnCalendario;
    private ImageView btnSettings,btnNotificaciones;
    private int idPaciente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main_principal_cliente);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Obtener ID del paciente desde SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        idPaciente = sharedPreferences.getInt(KEY_ID_USUARIO, 0);
        Log.d(TAG, "ID Paciente obtenido: " + idPaciente);

        btnDoctores = findViewById(R.id.btn_doctores);
        btnFavoritos = findViewById(R.id.tab_doctores);
        btnCalendario = findViewById(R.id.btn_calendario);
        btnSettings = findViewById(R.id.btn_settings);
        btnNotificaciones = findViewById(R.id.btn_notifications);

        if (btnDoctores == null || btnFavoritos == null || btnCalendario == null) {
            Log.e(TAG, "Error: Uno de los botones es nulo. Revisar IDs en XML.");
            Toast.makeText(this, "Error: botones de navegación no encontrados", Toast.LENGTH_LONG).show();
        }

        // Cargar fragment inicial
        cargarFragment(new fragment_doctores());

        // Manejar clics de navegación
        btnDoctores.setOnClickListener(v -> {
            Log.i(TAG, "Botón Calendario clickeado");
            Intent intent = new Intent(MainPrincipalCliente.this, ChatAsistenteActivity.class);
            startActivity(intent);
        });

        // 🔥 MODIFICADO: Click normal para favoritos + Long click para notificación de prueba
        btnFavoritos.setOnClickListener(v -> {
            Log.i(TAG, "Botón Calendario clickeado");
            Intent intent = new Intent(MainPrincipalCliente.this, Activity_Calendario.class);
            startActivity(intent);
        });



        btnCalendario.setOnClickListener(v -> {
            Log.i(TAG, "Botón Calendario clickeado");
            Intent intent = new Intent(MainPrincipalCliente.this, Activity_Calendario.class);
            startActivity(intent);
        });

        btnSettings.setOnClickListener(v -> {
            Log.i(TAG, "Botón Configuración clickeado");
            abrirMiPerfil();
        });

        btnNotificaciones.setOnClickListener(v -> {
            Log.i(TAG, "Botón Calendario clickeado");
            Intent intent = new Intent(MainPrincipalCliente.this, activity_notificaciones.class);
            startActivity(intent);
        });
    }

    private void cargarFragment(Fragment fragment) {
        if (fragment == null) {
            Log.e(TAG, "Error: fragmento es nulo, no se puede cargar.");
            return;
        }
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.fragment_container, fragment);
        transaction.commit();
        Log.i(TAG, "Fragmento cargado: " + fragment.getClass().getSimpleName());
    }

    private void abrirMiPerfil() {
        Intent intent = new Intent(MainPrincipalCliente.this, Perfil.class);
        startActivity(intent);
        Log.i(TAG, "Navegando a Mi Perfil");
    }


    private void dispararNotificacionDePrueba() {
        if (idPaciente == 0) {
            Toast.makeText(this, "⚠️ Error: ID de paciente no encontrado", Toast.LENGTH_LONG).show();
            Log.e(TAG, "No se puede disparar notificación: idPaciente = 0");
            return;
        }

        Log.d(TAG, "Disparando notificación de prueba para paciente ID: " + idPaciente);

        // Crear un Intent como si fuera una alarma real
        Intent intent = new Intent(this, AlarmReceiver.class);
        intent.putExtra("nombre_medicamento", "Paracetamol TEST");
        intent.putExtra("dosis", "500mg - PRUEBA INMEDIATA");
        intent.putExtra("hora_toma", "AHORA");
        intent.putExtra("id_paciente", idPaciente);
        intent.putExtra("notification_id", 99999);

        // Disparar el receiver manualmente
        AlarmReceiver receiver = new AlarmReceiver();
        receiver.onReceive(this, intent);

        Toast.makeText(this, "🔔 ¡Notificación de prueba disparada!\nRevisa tu barra de notificaciones", Toast.LENGTH_LONG).show();
        Log.i(TAG, "Notificación de prueba enviada correctamente");
    }
}